package com.herotoner.herotvvoice.command

/**
 * يحوّل نصاً عربياً (ناتج التعرف على الكلام) إلى أمر مفهوم، أو null إن لم يُفهم.
 * مطابقة قائمة على قواعد صريحة وثابتة — لا ذكاء اصطناعي ولا إرسال للنص لأي خادم.
 * كل الكلمات المفتاحية تمر عبر [ArabicNormalizer] نفسه فتتطابق صيغها مع النص المُوحَّد.
 */
object CommandParser {

    private fun n(s: String) = ArabicNormalizer.normalize(s)

    // جذور تُطابَق بالاحتواء داخل النص
    private val HOME_STEMS = listOf("رئيسي").map(::n)
    private val SETTINGS_STEMS = listOf("إعدادات", "settings").map(::n)
    private val MUTE_STEMS = listOf("كتم").map(::n)
    private val VOLUME_STEM = n("صوت")
    private val VOL_UP_STEMS = listOf("رفع", "زود", "زيد").map(::n)
    private val VOL_DOWN_STEMS = listOf("خفض", "نزل", "قلل", "وطي").map(::n)

    // كلمات كاملة (مع قبول البادئات ل / لل / ال)
    private val HOME_TOKENS = listOf("هوم", "home").map(::n)
    private val BACK_TOKENS = listOf("خلف", "رجوع", "ارجع").map(::n)
    private val UP_TOKENS = listOf("أعلى", "فوق", "اطلع", "اصعد").map(::n)
    private val DOWN_TOKENS = listOf("أسفل", "تحت", "انزل").map(::n)
    private val LEFT_TOKENS = listOf("يسار").map(::n)
    private val RIGHT_TOKENS = listOf("يمين").map(::n)
    private val SELECT_TOKENS = listOf("اختر", "اختار", "حدد", "تحديد", "موافق", "اوك", "ok", "اختيار").map(::n)

    private val OPEN_VERBS = listOf("افتح", "شغل", "افتحلي", "شغلي").map(::n)
    private val OPEN_FILLERS = listOf("تطبيق", "برنامج", "لي").map(::n).toSet()
    private val APP_ARG = Regex("^[\\p{L}\\p{N}]+( [\\p{L}\\p{N}]+)*$")
    private const val MAX_APP_ARG_LENGTH = 40

    fun parse(raw: String): ParsedCommand? {
        val t = ArabicNormalizer.normalize(raw)
        if (t.isEmpty()) return null
        val tokens = t.split(' ')

        fun hasStem(stems: List<String>) = stems.any { t.contains(it) }
        fun hasToken(words: List<String>) = tokens.any { tok -> prefixVariants(tok).any { it in words } }

        // 1) الشاشة الرئيسية — قبل "ارجع" حتى لا تُفهم كأمر رجوع
        if (hasStem(HOME_STEMS) || hasToken(HOME_TOKENS)) return ParsedCommand(TvAction.HOME)

        // 2) الإعدادات — قبل "افتح" حتى لا تُفهم كاسم تطبيق
        if (hasStem(SETTINGS_STEMS)) return ParsedCommand(TvAction.OPEN_SETTINGS)

        // 3) كتم الصوت
        if (hasStem(MUTE_STEMS)) return ParsedCommand(TvAction.MUTE)

        // 4) أوامر الصوت: إن ذُكر "الصوت" ولم يُفهم الفعل نرفض ولا نخمّن (مثل: "أعلى الصوت")
        if (t.contains(VOLUME_STEM)) {
            return when {
                hasStem(VOL_UP_STEMS) -> ParsedCommand(TvAction.VOLUME_UP)
                hasStem(VOL_DOWN_STEMS) -> ParsedCommand(TvAction.VOLUME_DOWN)
                else -> null
            }
        }

        // 5) فتح تطبيق
        if (tokens[0] in OPEN_VERBS) return parseOpenApp(tokens)

        // 6) رجوع / تنقل / اختيار
        if (hasToken(BACK_TOKENS)) return ParsedCommand(TvAction.BACK)
        if (hasToken(UP_TOKENS)) return ParsedCommand(TvAction.UP)
        if (hasToken(DOWN_TOKENS)) return ParsedCommand(TvAction.DOWN)
        if (hasToken(LEFT_TOKENS)) return ParsedCommand(TvAction.LEFT)
        if (hasToken(RIGHT_TOKENS)) return ParsedCommand(TvAction.RIGHT)
        if (hasToken(SELECT_TOKENS)) return ParsedCommand(TvAction.SELECT)

        return null
    }

    private fun parseOpenApp(tokens: List<String>): ParsedCommand? {
        val rest = tokens.drop(1).filterNot { it in OPEN_FILLERS }.toMutableList()
        if (rest.isEmpty()) return null
        // "اليوتيوب" → "يوتيوب"
        if (rest[0].startsWith("ال") && rest[0].length > 4) rest[0] = rest[0].removePrefix("ال")
        val arg = rest.joinToString(" ")
        if (arg.length > MAX_APP_ARG_LENGTH || !APP_ARG.matches(arg)) return null
        return ParsedCommand(TvAction.OPEN_APP, arg)
    }

    /** "للخلف" → ["للخلف", "خلف"]، "لفوق" → ["لفوق", "فوق"]، "الأعلى" → ["الاعلي", "اعلي"] */
    private fun prefixVariants(token: String): List<String> {
        val out = ArrayList<String>(4)
        out.add(token)
        if (token.startsWith("لل")) out.add(token.removePrefix("لل"))
        if (token.startsWith("ال")) out.add(token.removePrefix("ال"))
        if (token.startsWith("ل")) {
            val r = token.removePrefix("ل")
            out.add(r)
            if (r.startsWith("ال")) out.add(r.removePrefix("ال"))
        }
        return out
    }
}
