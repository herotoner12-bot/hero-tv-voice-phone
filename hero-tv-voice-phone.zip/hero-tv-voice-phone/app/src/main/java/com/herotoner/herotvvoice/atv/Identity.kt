package com.herotoner.herotvvoice.atv

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** هوية الهاتف: مفتاح RSA وشهادة موقّعة ذاتياً تُولَّد على الجهاز نفسه (لا مفاتيح داخل التطبيق). */
class ClientIdentity(val privateKey: PrivateKey, val certificate: X509Certificate) {

    fun serialize(): ByteArray {
        val bos = ByteArrayOutputStream()
        DataOutputStream(bos).use { out ->
            val k = privateKey.encoded
            val c = certificate.encoded
            out.writeInt(1) // نسخة الصيغة
            out.writeInt(k.size); out.write(k)
            out.writeInt(c.size); out.write(c)
        }
        return bos.toByteArray()
    }

    companion object {
        fun deserialize(data: ByteArray): ClientIdentity {
            DataInputStream(ByteArrayInputStream(data)).use { input ->
                require(input.readInt() == 1) { "unknown identity format" }
                val k = ByteArray(input.readInt().also { require(it in 1..16384) }).also { input.readFully(it) }
                val c = ByteArray(input.readInt().also { require(it in 1..16384) }).also { input.readFully(it) }
                val key = KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(k))
                val cert = CertificateFactory.getInstance("X.509")
                    .generateCertificate(ByteArrayInputStream(c)) as X509Certificate
                return ClientIdentity(key, cert)
            }
        }

        fun generate(commonName: String = "herotvvoice"): ClientIdentity {
            val kpg = KeyPairGenerator.getInstance("RSA")
            kpg.initialize(2048)
            val kp = kpg.generateKeyPair()
            val der = X509Builder.selfSigned(kp.public as RSAPublicKey, kp.private, commonName)
            val cert = CertificateFactory.getInstance("X.509")
                .generateCertificate(ByteArrayInputStream(der)) as X509Certificate
            return ClientIdentity(kp.private, cert)
        }
    }
}

/** مكان حفظ الهوية (على أندرويد: ملف مشفّر بمفتاح AndroidKeyStore). */
interface IdentityStore {
    fun load(): ClientIdentity?
    fun save(identity: ClientIdentity)
    fun clear()
}

class InMemoryIdentityStore : IdentityStore {
    private var data: ByteArray? = null
    override fun load(): ClientIdentity? = data?.let { ClientIdentity.deserialize(it) }
    override fun save(identity: ClientIdentity) { data = identity.serialize() }
    override fun clear() { data = null }
}

fun IdentityStore.loadOrCreate(): ClientIdentity = load() ?: ClientIdentity.generate().also { save(it) }

/** بصمة SHA-256 بصيغة hex كبيرة مفصولة بنقطتين. */
fun fingerprintSha256(der: ByteArray): String =
    MessageDigest.getInstance("SHA-256").digest(der).joinToString(":") { "%02X".format(it) }

/** باني شهادة X.509 v3 موقّعة ذاتياً (RSA + SHA256) بصيغة DER — لتفادي مكتبات خارجية. */
object X509Builder {
    private fun len(n: Int): ByteArray = when {
        n < 0x80 -> byteArrayOf(n.toByte())
        n < 0x100 -> byteArrayOf(0x81.toByte(), n.toByte())
        n < 0x10000 -> byteArrayOf(0x82.toByte(), (n shr 8).toByte(), n.toByte())
        else -> throw IllegalArgumentException("too long")
    }

    private fun tlv(tag: Int, vararg parts: ByteArray): ByteArray {
        val body = ByteArrayOutputStream()
        parts.forEach { body.write(it) }
        val b = body.toByteArray()
        return byteArrayOf(tag.toByte()) + len(b.size) + b
    }

    private fun seq(vararg p: ByteArray) = tlv(0x30, *p)
    private fun set(vararg p: ByteArray) = tlv(0x31, *p)
    private fun integer(v: BigInteger) = tlv(0x02, v.toByteArray())
    private fun oid(vararg arcs: Int): ByteArray {
        val b = ByteArrayOutputStream()
        b.write(arcs[0] * 40 + arcs[1])
        for (i in 2 until arcs.size) {
            var v = arcs[i]
            val stack = ArrayList<Int>()
            stack.add(v and 0x7F)
            v = v shr 7
            while (v > 0) { stack.add((v and 0x7F) or 0x80); v = v shr 7 }
            for (j in stack.indices.reversed()) b.write(stack[j])
        }
        return tlv(0x06, b.toByteArray())
    }

    private val NULL = byteArrayOf(0x05, 0x00)
    private val SHA256_RSA = seq(oid(1, 2, 840, 113549, 1, 1, 11), NULL)

    private fun utcTime(d: Date): ByteArray {
        val f = SimpleDateFormat("yyMMddHHmmss'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return tlv(0x17, f.format(d).toByteArray(Charsets.US_ASCII))
    }

    fun selfSigned(pub: RSAPublicKey, priv: PrivateKey, cn: String, serial: Long = 1000): ByteArray {
        val name = seq(set(seq(oid(2, 5, 4, 3), tlv(0x0C, cn.toByteArray(Charsets.UTF_8)))))
        val now = System.currentTimeMillis()
        val validity = seq(utcTime(Date(now - 3_600_000L)), utcTime(Date(now + 10L * 365 * 24 * 3600 * 1000)))

        val basicConstraints = seq(
            oid(2, 5, 29, 19),
            tlv(0x04, seq(tlv(0x01, byteArrayOf(0xFF.toByte())), tlv(0x02, byteArrayOf(0)))),
        )
        val san = seq(
            oid(2, 5, 29, 17),
            tlv(0x04, seq(tlv(0x82, cn.toByteArray(Charsets.US_ASCII)))),
        )
        val extensions = tlv(0xA3, seq(basicConstraints, san))

        val tbs = seq(
            tlv(0xA0, tlv(0x02, byteArrayOf(2))), // version v3
            integer(BigInteger.valueOf(serial)),
            SHA256_RSA,
            name,
            validity,
            name,
            pub.encoded, // SubjectPublicKeyInfo
            extensions,
        )
        val sig = Signature.getInstance("SHA256withRSA").run {
            initSign(priv)
            update(tbs)
            sign()
        }
        return seq(tbs, SHA256_RSA, tlv(0x03, byteArrayOf(0) + sig))
    }
}

/** القيمة الصحيحة الموجبة كبايتات big-endian بأقل حجم (بدون بايت إشارة). */
fun BigInteger.toMinimalBytes(): ByteArray {
    val b = toByteArray()
    return if (b.size > 1 && b[0].toInt() == 0) b.copyOfRange(1, b.size) else b
}
