package com.herotoner.herotvvoice.atv

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * يحفظ هوية الهاتف (مفتاح RSA + شهادة) في ملف خاص بالتطبيق، مشفّراً بمفتاح AES-GCM
 * لا يغادر AndroidKeyStore. لا توجد مفاتيح مدمجة داخل التطبيق.
 */
class AndroidIdentityStore(private val context: Context) : IdentityStore {

    private val file: File get() = File(context.filesDir, FILE_NAME)

    private fun wrapKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }

    override fun load(): ClientIdentity? {
        val f = file
        if (!f.exists()) return null
        return try {
            val all = f.readBytes()
            val iv = all.copyOfRange(0, IV_BYTES)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, wrapKey(), GCMParameterSpec(128, iv))
            ClientIdentity.deserialize(cipher.doFinal(all, IV_BYTES, all.size - IV_BYTES))
        } catch (e: Exception) {
            null // ملف تالف أو مفتاح مفقود: تُولَّد هوية جديدة ويلزم اقتران جديد
        }
    }

    override fun save(identity: ClientIdentity) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, wrapKey())
        val ct = cipher.doFinal(identity.serialize())
        file.writeBytes(cipher.iv + ct)
    }

    override fun clear() {
        file.delete()
        try {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (ks.containsAlias(ALIAS)) ks.deleteEntry(ALIAS)
        } catch (_: Exception) {
        }
    }

    private companion object {
        const val FILE_NAME = "tv_identity.bin"
        const val ALIAS = "herotvvoice_identity_wrap"
        const val IV_BYTES = 12
    }
}
