package com.herotoner.herotvvoice.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.herotoner.herotvvoice.R
import com.herotoner.herotvvoice.command.CommandParser
import com.herotoner.herotvvoice.command.PendingCommand
import com.herotoner.herotvvoice.command.TvSupport
import com.herotoner.herotvvoice.databinding.ActivityMainBinding
import com.herotoner.herotvvoice.speech.SpeechController
import com.herotoner.herotvvoice.speech.SpeechFailure
import java.util.UUID

/**
 * المرحلة 1: الواجهة + التعرف على الكلام + فهم الأمر + عرضه للموافقة.
 * الاتصال بالتلفزيون غير منفّذ بعد (المرحلة 2)، لذلك زر "موافقة وإرسال" معطّل عمداً
 * وحالة الاتصال تُعرض بصدق: غير متصل.
 */
class MainActivity : AppCompatActivity(), SpeechController.Listener {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: SharedPreferences
    private lateinit var speech: SpeechController

    private var state: UiState = UiState.Idle
    private var lastMicTapMs = 0L

    private val micPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) {
                beginListening()
            } else {
                render(UiState.Failed(R.string.err_permission_denied, offerAppSettings = true))
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        speech = SpeechController(this, this)

        b.offlineSwitch.isChecked = prefs.getBoolean(KEY_PREFER_OFFLINE, false)
        b.offlineSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(KEY_PREFER_OFFLINE, checked).apply()
        }

        b.micButton.setOnClickListener { onMicTapped() }
        b.cancelButton.setOnClickListener { onCancel() }
        b.retryButton.setOnClickListener { startFlow() }
        b.approveButton.setOnClickListener {
            // معطّل في المرحلة 1؛ حماية إضافية فقط.
            Toast.makeText(this, R.string.send_unavailable_toast, Toast.LENGTH_SHORT).show()
        }
        b.settingsButton.setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
            )
        }
        b.findTvButton.setOnClickListener {
            startActivity(Intent(this, DiagnosticsActivity::class.java))
        }

        render(UiState.Idle)
    }

    override fun onStop() {
        super.onStop()
        // لا نترك الميكروفون مفتوحاً في الخلفية
        if (state is UiState.Listening || state is UiState.Processing) {
            speech.cancel()
            render(UiState.Idle)
        }
    }

    override fun onDestroy() {
        speech.release()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- التفاعل

    private fun onMicTapped() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastMicTapMs < MIC_DEBOUNCE_MS) return // منع الضغط المزدوج غير المقصود
        lastMicTapMs = now

        when (state) {
            is UiState.Listening -> {
                speech.stop() // يطلب النتيجة النهائية
                render(UiState.Processing)
            }
            is UiState.Processing -> Unit
            else -> startFlow()
        }
    }

    private fun onCancel() {
        speech.cancel()
        render(UiState.Cancelled)
    }

    private fun startFlow() {
        if (!SpeechController.isAvailable(this)) {
            render(UiState.Failed(R.string.err_no_recognizer))
            return
        }
        if (!prefs.getBoolean(KEY_CONSENT, false)) {
            showConsentDialog()
            return
        }
        val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) beginListening() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun showConsentDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.consent_title)
            .setMessage(R.string.consent_message)
            .setPositiveButton(R.string.consent_accept) { _, _ ->
                prefs.edit().putBoolean(KEY_CONSENT, true).apply()
                startFlow()
            }
            .setNegativeButton(R.string.consent_decline, null)
            .show()
    }

    private fun beginListening() {
        try {
            speech.start(preferOffline = b.offlineSwitch.isChecked)
            render(UiState.Listening)
        } catch (e: Exception) {
            speech.cancel()
            render(UiState.Failed(R.string.err_start_failed))
        }
    }

    // ---------------------------------------------------- SpeechController.Listener

    override fun onSpeechBegin() {
        b.stateText.setText(R.string.state_hearing)
    }

    override fun onLevel(rmsDb: Float) {
        if (state !is UiState.Listening) return
        val scale = 1f + (rmsDb.coerceIn(0f, 10f) / 10f) * 0.12f
        b.micButton.scaleX = scale
        b.micButton.scaleY = scale
    }

    override fun onPartial(text: String) {
        if (state is UiState.Listening) b.transcriptText.text = text
    }

    override fun onResults(alternatives: List<String>) {
        // نأخذ أول بديل يُفهم كأمر؛ وإلا نعرض أفضل نص تعرّف عليه التطبيق.
        val match = alternatives.firstNotNullOfOrNull { alt ->
            CommandParser.parse(alt)?.let { alt to it }
        }
        if (match != null) {
            val pending = PendingCommand(
                requestId = UUID.randomUUID().toString(),
                command = match.second,
                spokenText = match.first,
                createdAtMs = System.currentTimeMillis(),
            )
            render(UiState.Understood(match.first, pending))
        } else {
            render(UiState.NotUnderstood(alternatives.firstOrNull().orEmpty()))
        }
    }

    override fun onFailure(failure: SpeechFailure) {
        val message = when (failure) {
            SpeechFailure.NO_SPEECH -> R.string.err_no_speech
            SpeechFailure.NETWORK -> R.string.err_network
            SpeechFailure.PERMISSION -> R.string.err_permission_denied
            SpeechFailure.BUSY -> R.string.err_busy
            SpeechFailure.LANGUAGE_UNAVAILABLE -> R.string.err_language
            SpeechFailure.AUDIO -> R.string.err_audio
            SpeechFailure.SERVER -> R.string.err_server
            SpeechFailure.OTHER -> R.string.err_other
        }
        render(UiState.Failed(message, offerAppSettings = failure == SpeechFailure.PERMISSION))
    }

    // ---------------------------------------------------------------- العرض

    private fun render(newState: UiState) {
        state = newState

        b.micButton.scaleX = 1f
        b.micButton.scaleY = 1f
        b.micButton.isSelected = newState is UiState.Listening

        // الاتصال بالتلفزيون: غير منفّذ بعد — نقول ذلك بصراحة
        b.connectionText.setText(R.string.conn_not_connected)
        b.connectionDetail.setText(R.string.conn_phase2_pending)

        b.commandCard.visibility = View.GONE
        b.cancelButton.visibility = View.GONE
        b.retryButton.visibility = View.GONE
        b.settingsButton.visibility = View.GONE

        when (newState) {
            UiState.Idle -> {
                b.stateText.setText(R.string.state_idle)
                b.transcriptText.setText(R.string.transcript_empty)
            }
            UiState.Listening -> {
                b.stateText.setText(R.string.state_listening)
                b.transcriptText.setText(R.string.transcript_empty)
                b.cancelButton.visibility = View.VISIBLE
            }
            UiState.Processing -> {
                b.stateText.setText(R.string.state_processing)
                b.cancelButton.visibility = View.VISIBLE
            }
            UiState.Cancelled -> {
                b.stateText.setText(R.string.state_cancelled)
                b.transcriptText.setText(R.string.transcript_empty)
                b.retryButton.visibility = View.VISIBLE
            }
            is UiState.Understood -> {
                b.stateText.setText(R.string.state_understood)
                b.transcriptText.text = newState.transcript
                b.commandText.text = newState.pending.command.displayLabel
                b.commandCard.visibility = View.VISIBLE
                b.approveButton.isEnabled = false // لا اقتران بعد
                val note = StringBuilder(getString(R.string.send_unavailable_note))
                if (newState.pending.command.action.tvSupport == TvSupport.NOT_IN_TV_VOCABULARY) {
                    note.append("\n").append(getString(R.string.send_not_in_tv_vocab))
                }
                b.commandNote.text = note.toString()
                b.cancelButton.visibility = View.VISIBLE
                b.retryButton.visibility = View.VISIBLE
            }
            is UiState.NotUnderstood -> {
                b.stateText.setText(R.string.state_not_understood)
                b.transcriptText.text =
                    newState.transcript.ifBlank { getString(R.string.transcript_empty) }
                b.retryButton.visibility = View.VISIBLE
            }
            is UiState.Failed -> {
                b.stateText.setText(newState.messageRes)
                b.transcriptText.setText(R.string.transcript_empty)
                b.retryButton.visibility = View.VISIBLE
                if (newState.offerAppSettings) b.settingsButton.visibility = View.VISIBLE
            }
        }
    }

    private companion object {
        const val PREFS = "hero_tv_voice_prefs"
        const val KEY_CONSENT = "speech_consent_v1"
        const val KEY_PREFER_OFFLINE = "prefer_offline"
        const val MIC_DEBOUNCE_MS = 600L
    }
}
