package com.herotoner.herotvvoice.atv

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream

/**
 * Protobuf wire format بسيط يدوياً (varint + length-delimited فقط) — بلا أي مكتبة.
 * يتبع قواعد proto3: الحقول العددية ذات القيمة 0 لا تُرسل، والرسائل المتداخلة تُرسل دائماً إن طُلب.
 */
class ProtoWriter {
    private val out = ByteArrayOutputStream()

    private fun varint(value: Long) {
        var v = value
        while (true) {
            if ((v and 0x7FL.inv()) == 0L) {
                out.write(v.toInt())
                return
            }
            out.write(((v and 0x7F) or 0x80).toInt())
            v = v ushr 7
        }
    }

    private fun tag(field: Int, wire: Int) = varint(((field shl 3) or wire).toLong())

    /** int32/uint32/enum: القيمة 0 تُحذف (proto3). السالب يُرمَّز 10 بايت كما في المواصفة. */
    fun int32(field: Int, value: Int): ProtoWriter {
        if (value != 0) {
            tag(field, 0)
            varint(value.toLong())
        }
        return this
    }

    fun bool(field: Int, value: Boolean): ProtoWriter {
        if (value) {
            tag(field, 0)
            varint(1)
        }
        return this
    }

    fun string(field: Int, value: String): ProtoWriter {
        if (value.isNotEmpty()) bytes(field, value.toByteArray(Charsets.UTF_8))
        return this
    }

    /** يُرسل دائماً حتى لو كان فارغاً (لرسالة متداخلة موجودة أو حقل bytes صريح). */
    fun bytes(field: Int, value: ByteArray): ProtoWriter {
        tag(field, 2)
        varint(value.size.toLong())
        out.write(value)
        return this
    }

    fun message(field: Int, build: ProtoWriter.() -> Unit): ProtoWriter =
        bytes(field, ProtoWriter().apply(build).toByteArray())

    fun toByteArray(): ByteArray = out.toByteArray()
}

class ProtoException(message: String) : IOException(message)

class ProtoField(val number: Int, val wire: Int, val varint: Long, val bytes: ByteArray?)

object ProtoReader {
    fun parse(data: ByteArray): List<ProtoField> {
        val fields = ArrayList<ProtoField>()
        var pos = 0
        fun readVarint(): Long {
            var result = 0L
            var shift = 0
            while (true) {
                if (pos >= data.size) throw ProtoException("varint truncated")
                if (shift > 63) throw ProtoException("varint too long")
                val b = data[pos++].toInt() and 0xFF
                result = result or ((b and 0x7F).toLong() shl shift)
                if (b and 0x80 == 0) return result
                shift += 7
            }
        }
        while (pos < data.size) {
            val key = readVarint()
            val number = (key ushr 3).toInt()
            if (number <= 0) throw ProtoException("bad field number")
            when (val wire = (key and 7).toInt()) {
                0 -> fields.add(ProtoField(number, wire, readVarint(), null))
                1 -> {
                    if (pos + 8 > data.size) throw ProtoException("fixed64 truncated")
                    fields.add(ProtoField(number, wire, 0, data.copyOfRange(pos, pos + 8)))
                    pos += 8
                }
                2 -> {
                    val len = readVarint()
                    if (len < 0 || len > data.size - pos) throw ProtoException("length-delimited truncated")
                    fields.add(ProtoField(number, wire, 0, data.copyOfRange(pos, pos + len.toInt())))
                    pos += len.toInt()
                }
                5 -> {
                    if (pos + 4 > data.size) throw ProtoException("fixed32 truncated")
                    fields.add(ProtoField(number, wire, 0, data.copyOfRange(pos, pos + 4)))
                    pos += 4
                }
                else -> throw ProtoException("unsupported wire type $wire")
            }
        }
        return fields
    }
}

fun List<ProtoField>.bytesOf(number: Int): ByteArray? = lastOrNull { it.number == number && it.wire == 2 }?.bytes
fun List<ProtoField>.intOf(number: Int): Int = lastOrNull { it.number == number && it.wire == 0 }?.varint?.toInt() ?: 0
fun List<ProtoField>.boolOf(number: Int): Boolean = intOf(number) != 0
fun List<ProtoField>.stringOf(number: Int): String = bytesOf(number)?.toString(Charsets.UTF_8) ?: ""
fun List<ProtoField>.hasField(number: Int): Boolean = any { it.number == number }
fun List<ProtoField>.allBytesOf(number: Int): List<ByteArray> =
    filter { it.number == number && it.wire == 2 }.mapNotNull { it.bytes }

/** إطار الرسائل: طول varint ثم الرسالة. حدّ أعلى للحجم لحماية الذاكرة. */
object Frames {
    const val MAX_FRAME_BYTES = 1 shl 20

    fun write(out: OutputStream, message: ByteArray) {
        val header = ByteArrayOutputStream()
        var v = message.size.toLong()
        while (true) {
            if ((v and 0x7FL.inv()) == 0L) {
                header.write(v.toInt())
                break
            }
            header.write(((v and 0x7F) or 0x80).toInt())
            v = v ushr 7
        }
        out.write(header.toByteArray())
        out.write(message)
        out.flush()
    }

    /** يقرأ إطاراً كاملاً. null عند إغلاق الاتصال نظيفاً قبل بدء إطار. */
    fun read(input: InputStream): ByteArray? {
        var len = 0L
        var shift = 0
        var first = true
        while (true) {
            val b = input.read()
            if (b < 0) {
                if (first) return null
                throw ProtoException("connection closed inside frame header")
            }
            first = false
            if (shift > 28) throw ProtoException("frame length varint too long")
            len = len or ((b and 0x7F).toLong() shl shift)
            if (b and 0x80 == 0) break
            shift += 7
        }
        if (len < 0 || len > MAX_FRAME_BYTES) throw ProtoException("frame too large: $len")
        val buf = ByteArray(len.toInt())
        var off = 0
        while (off < buf.size) {
            val n = input.read(buf, off, buf.size - off)
            if (n < 0) throw ProtoException("connection closed inside frame")
            off += n
        }
        return buf
    }
}
