package com.herotoner.herotvvoice.atv

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import java.net.Inet4Address

/**
 * اكتشاف أجهزة Android TV على الشبكة المحلية عبر mDNS: الخدمة _androidtvremote2._tcp.
 * تتوقف تلقائياً بعد 15 ثانية. كل النداءات الراجعة تصل على الخيط الرئيسي.
 */
class NsdDiscovery(context: Context, private val callback: Callback) {

    interface Callback {
        fun onFound(name: String, host: String, port: Int)
        fun onLog(line: String)
        fun onStopped(foundCount: Int)
    }

    private val appContext = context.applicationContext
    private val nsd = appContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifi = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val main = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false
    private var listener: NsdManager.DiscoveryListener? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private var found = 0

    var isRunning = false
        private set

    private val autoStop = Runnable { stop() }

    fun start() {
        if (isRunning) return
        found = 0
        queue.clear()
        resolving = false
        try {
            multicastLock = wifi.createMulticastLock("herotvvoice-nsd").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (e: Exception) {
            callback.onLog("تعذّر أخذ قفل البث المتعدد: ${e.message}")
        }
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {
                main.post { callback.onLog("بدأ البحث عن $serviceType") }
            }

            override fun onServiceFound(info: NsdServiceInfo) {
                main.post {
                    callback.onLog("عُثر على خدمة: ${info.serviceName}")
                    queue.addLast(info)
                    resolveNext()
                }
            }

            override fun onServiceLost(info: NsdServiceInfo) {}
            override fun onDiscoveryStopped(serviceType: String) {}

            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                main.post {
                    callback.onLog("فشل بدء البحث (رمز $errorCode)")
                    stop()
                }
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
        }
        listener = l
        isRunning = true
        try {
            nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, l)
            main.postDelayed(autoStop, DISCOVERY_MS)
        } catch (e: Exception) {
            callback.onLog("خطأ في بدء البحث: ${e.message}")
            stop()
        }
    }

    @Suppress("DEPRECATION")
    private fun resolveNext() {
        if (resolving) return
        val info = queue.removeFirstOrNull() ?: return
        resolving = true
        try {
            nsd.resolveService(info, object : NsdManager.ResolveListener {
                override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                    main.post {
                        callback.onLog("تعذّر تحديد عنوان ${serviceInfo.serviceName} (رمز $errorCode)")
                        resolving = false
                        resolveNext()
                    }
                }

                override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                    main.post {
                        val addr = serviceInfo.host
                        if (addr is Inet4Address && addr.hostAddress != null) {
                            found++
                            callback.onFound(serviceInfo.serviceName, addr.hostAddress!!, serviceInfo.port)
                        } else {
                            callback.onLog("تجاهل ${serviceInfo.serviceName}: لا يوجد عنوان IPv4")
                        }
                        resolving = false
                        resolveNext()
                    }
                }
            })
        } catch (e: Exception) {
            callback.onLog("خطأ أثناء تحديد العنوان: ${e.message}")
            resolving = false
        }
    }

    fun stop() {
        if (!isRunning) return
        isRunning = false
        main.removeCallbacks(autoStop)
        listener?.let {
            try {
                nsd.stopServiceDiscovery(it)
            } catch (_: Exception) {
            }
        }
        listener = null
        try {
            multicastLock?.takeIf { it.isHeld }?.release()
        } catch (_: Exception) {
        }
        multicastLock = null
        callback.onStopped(found)
    }

    private companion object {
        const val SERVICE_TYPE = "_androidtvremote2._tcp"
        const val DISCOVERY_MS = 15_000L
    }
}
