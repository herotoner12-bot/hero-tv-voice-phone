package com.herotoner.herotvvoice.atv

import java.io.Closeable
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException
import java.security.MessageDigest
import java.security.Principal
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocket
import javax.net.ssl.X509ExtendedKeyManager
import javax.net.ssl.X509TrustManager

/**
 * اتصال TLS بتلفزيون Android TV على الشبكة المحلية.
 * شهادة التلفزيون موقّعة ذاتياً، لذلك لا يمكن التحقق منها بسلسلة ثقة؛ الأمان يأتي من:
 *  1) رمز PIN الذي يربط شهادتي الطرفين أثناء الاقتران (يكشف أي وسيط)،
 *  2) تثبيت بصمة شهادة التلفزيون بعد الاقتران ورفض أي شهادة مختلفة في الاتصالات التالية.
 */
object Tls {
    const val PAIRING_PORT = 6467
    const val REMOTE_PORT = 6466

    class CapturingTrustManager(private val pinnedFingerprint: String?) : X509TrustManager {
        @Volatile
        var serverCert: X509Certificate? = null

        override fun checkClientTrusted(chain: Array<X509Certificate>?, authType: String?) {
            throw CertificateException("client authentication is not supported")
        }

        override fun checkServerTrusted(chain: Array<X509Certificate>?, authType: String?) {
            val leaf = chain?.firstOrNull() ?: throw CertificateException("empty server certificate chain")
            serverCert = leaf
            if (pinnedFingerprint != null && fingerprintSha256(leaf.encoded) != pinnedFingerprint) {
                throw CertificateException("server certificate does not match the pinned certificate")
            }
        }

        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    }

    /** يرسل شهادتنا دائماً بغض النظر عن قائمة جهات الإصدار التي يطلبها التلفزيون. */
    private class FixedKeyManager(
        private val key: PrivateKey,
        private val chain: Array<X509Certificate>,
    ) : X509ExtendedKeyManager() {
        private val alias = "client"
        override fun getClientAliases(keyType: String?, issuers: Array<Principal>?) = arrayOf(alias)
        override fun chooseClientAlias(keyType: Array<String>?, issuers: Array<Principal>?, socket: Socket?) = alias
        override fun chooseEngineClientAlias(keyType: Array<String>?, issuers: Array<Principal>?, engine: javax.net.ssl.SSLEngine?) = alias
        override fun getServerAliases(keyType: String?, issuers: Array<Principal>?): Array<String>? = null
        override fun chooseServerAlias(keyType: String?, issuers: Array<Principal>?, socket: Socket?): String? = null
        override fun getCertificateChain(alias: String?) = chain
        override fun getPrivateKey(alias: String?) = key
    }

    class Connection(val socket: SSLSocket, val serverCert: X509Certificate) : Closeable {
        override fun close() {
            try {
                socket.close()
            } catch (_: IOException) {
            }
        }
    }

    fun connect(
        host: String,
        port: Int,
        identity: ClientIdentity?,
        pinnedFingerprint: String? = null,
        connectTimeoutMs: Int = 4000,
        readTimeoutMs: Int = 10000,
    ): Connection {
        val trust = CapturingTrustManager(pinnedFingerprint)
        val keyManagers = identity?.let {
            arrayOf<javax.net.ssl.KeyManager>(FixedKeyManager(it.privateKey, arrayOf(it.certificate)))
        }
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(keyManagers, arrayOf(trust), SecureRandom())

        val raw = Socket()
        try {
            raw.connect(InetSocketAddress(host, port), connectTimeoutMs)
            raw.soTimeout = readTimeoutMs
            raw.tcpNoDelay = true
            val ssl = ctx.socketFactory.createSocket(raw, host, port, true) as SSLSocket
            ssl.startHandshake()
            val cert = trust.serverCert ?: throw IOException("no server certificate captured")
            return Connection(ssl, cert)
        } catch (e: Exception) {
            try {
                raw.close()
            } catch (_: IOException) {
            }
            throw e
        }
    }
}

/** تحويل الاستثناءات التقنية إلى سبب مفهوم (يُعرض ويُسجَّل). */
fun describeNetworkError(e: Throwable): String = when (e) {
    is SocketTimeoutException -> "انتهت المهلة"
    is java.net.ConnectException -> "رُفض الاتصال أو المنفذ مغلق"
    is java.net.NoRouteToHostException -> "لا مسار إلى الجهاز"
    is java.net.UnknownHostException -> "عنوان غير صالح"
    is javax.net.ssl.SSLHandshakeException -> "فشلت مصافحة TLS: ${e.message ?: ""}".trim()
    is javax.net.ssl.SSLException -> "خطأ TLS: ${e.message ?: ""}".trim()
    else -> "${e.javaClass.simpleName}: ${e.message ?: ""}".trim()
}

object PortProbe {
    class Tcp(val port: Int, val open: Boolean, val millis: Long, val error: String?)
    class TlsResult(val ok: Boolean, val subject: String?, val fingerprint: String?, val error: String?)

    fun tcp(host: String, port: Int, timeoutMs: Int = 3000): Tcp {
        val start = System.nanoTime()
        return try {
            Socket().use { it.connect(InetSocketAddress(host, port), timeoutMs) }
            Tcp(port, true, (System.nanoTime() - start) / 1_000_000, null)
        } catch (e: Exception) {
            Tcp(port, false, (System.nanoTime() - start) / 1_000_000, describeNetworkError(e))
        }
    }

    /** مصافحة TLS فقط (بلا أي رسالة بروتوكول): هل يتحدث المنفذ TLS ومن هو صاحب الشهادة؟ */
    fun tls(host: String, port: Int, identity: ClientIdentity?): TlsResult = try {
        Tls.connect(host, port, identity, null, 4000, 4000).use { c ->
            TlsResult(true, c.serverCert.subjectX500Principal.name, fingerprintSha256(c.serverCert.encoded), null)
        }
    } catch (e: Exception) {
        TlsResult(false, null, null, describeNetworkError(e))
    }
}

class PairingException(message: String, val kind: Kind) : Exception(message) {
    enum class Kind { CONNECT, TIMEOUT, PROTOCOL, REJECTED, BAD_PIN }
}

/** الاقتران برمز PIN (المنفذ 6467). الاستدعاءات متزامنة — شغّلها على خيط خلفي. */
class PairingClient(
    private val identity: ClientIdentity,
    private val clientName: String = "HERO TV VOICE",
) : Closeable {
    private var conn: Tls.Connection? = null

    /** هل ما زال اتصال الاقتران مفتوحاً (يمكن إعادة إدخال الرمز بعد خطأ محلي في الرمز)؟ */
    val isConnected: Boolean get() = conn != null

    companion object {
        /** SHA256(modulus_c | exp_c | modulus_s | exp_s | bytes(pin[2:])) — البايت الأول يجب أن يساوي pin[0:2]. */
        fun computeSecret(client: X509Certificate, server: X509Certificate, pin: String): ByteArray {
            val p = normalizePin(pin)
            val c = client.publicKey as? RSAPublicKey ?: throw PairingException("شهادة الهاتف ليست RSA", PairingException.Kind.PROTOCOL)
            val s = server.publicKey as? RSAPublicKey ?: throw PairingException("شهادة التلفزيون ليست RSA", PairingException.Kind.PROTOCOL)
            val h = MessageDigest.getInstance("SHA-256")
            h.update(c.modulus.toMinimalBytes())
            h.update(c.publicExponent.toMinimalBytes())
            h.update(s.modulus.toMinimalBytes())
            h.update(s.publicExponent.toMinimalBytes())
            h.update(hexToBytes(p.substring(2)))
            return h.digest()
        }

        fun normalizePin(pin: String): String {
            val p = pin.trim().replace(" ", "").uppercase()
            if (p.length != 6 || !p.all { it in '0'..'9' || it in 'A'..'F' }) {
                throw PairingException("الرمز يجب أن يكون 6 خانات (أرقام وحروف A-F)", PairingException.Kind.BAD_PIN)
            }
            return p
        }

        private fun hexToBytes(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    /** يتصل ويُنهي مصافحة الاقتران حتى يعرض التلفزيون الرمز. يعيد بصمة شهادة التلفزيون. */
    fun start(host: String, port: Int = Tls.PAIRING_PORT): String {
        close()
        val c = try {
            Tls.connect(host, port, identity)
        } catch (e: Exception) {
            throw PairingException("تعذّر الاتصال بمنفذ الاقتران: ${describeNetworkError(e)}", PairingException.Kind.CONNECT)
        }
        conn = c
        try {
            send(Polo.pairingRequest("atvremote", clientName))
            while (true) {
                val m = Polo.parse(readFrame())
                if (m.status != Polo.STATUS_OK) {
                    throw PairingException("رفض التلفزيون الاقتران (الحالة ${m.status})", PairingException.Kind.REJECTED)
                }
                when (m.kind) {
                    Polo.Kind.PAIRING_REQUEST_ACK -> send(Polo.options())
                    Polo.Kind.OPTIONS -> send(Polo.configuration())
                    Polo.Kind.CONFIGURATION_ACK -> return fingerprintSha256(c.serverCert.encoded)
                    else -> throw PairingException("رسالة اقتران غير متوقعة", PairingException.Kind.PROTOCOL)
                }
            }
        } catch (e: PairingException) {
            close()
            throw e
        } catch (e: Exception) {
            close()
            throw mapIo(e)
        }
    }

    /** يُكمل الاقتران بالرمز الظاهر على التلفزيون. يعيد بصمة شهادة التلفزيون لتثبيتها. */
    fun finish(pin: String): String {
        val c = conn ?: throw PairingException("لم يبدأ الاقتران", PairingException.Kind.PROTOCOL)
        val secret = computeSecret(identity.certificate, c.serverCert, pin)
        val p = normalizePin(pin)
        if ((secret[0].toInt() and 0xFF) != p.substring(0, 2).toInt(16)) {
            throw PairingException("الرمز غير صحيح (فشل التحقق المحلي قبل الإرسال)", PairingException.Kind.BAD_PIN)
        }
        try {
            send(Polo.secret(secret))
            val m = Polo.parse(readFrame())
            if (m.status == Polo.STATUS_BAD_SECRET) throw PairingException("رفض التلفزيون الرمز", PairingException.Kind.BAD_PIN)
            if (m.status != Polo.STATUS_OK) throw PairingException("رفض التلفزيون الاقتران (الحالة ${m.status})", PairingException.Kind.REJECTED)
            if (m.kind != Polo.Kind.SECRET_ACK) throw PairingException("رد غير متوقع بعد الرمز", PairingException.Kind.PROTOCOL)
            return fingerprintSha256(c.serverCert.encoded)
        } catch (e: PairingException) {
            throw e
        } catch (e: Exception) {
            throw mapIo(e)
        } finally {
            close()
        }
    }

    private fun send(msg: ByteArray) = Frames.write(conn!!.socket.outputStream, msg)

    private fun readFrame(): ByteArray =
        Frames.read(conn!!.socket.inputStream)
            ?: throw PairingException("أغلق التلفزيون الاتصال", PairingException.Kind.PROTOCOL)

    private fun mapIo(e: Exception): PairingException =
        if (e is SocketTimeoutException) PairingException("لم يرد التلفزيون في الوقت المحدد", PairingException.Kind.TIMEOUT)
        else PairingException("خطأ أثناء الاقتران: ${describeNetworkError(e)}", PairingException.Kind.PROTOCOL)

    override fun close() {
        conn?.close()
        conn = null
    }
}

/** حالة حقل الكتابة كما يبلّغ بها التلفزيون (قد تكون غير متاحة إن لم يكن هناك حقل مركّز). */
data class ImeState(
    val hasFieldStatus: Boolean = false,
    val appPackage: String = "",
    val appLabel: String = "",
    val imeCounter: Int = 0,
    val fieldCounter: Int = 0,
    val value: String = "",
    val updatedAtMs: Long = 0,
)

class RemoteInfo(val vendor: String, val model: String, val appVersion: String, val supportedFeatures: Int, val activeFeatures: Int) {
    val supportsKeys get() = supportedFeatures and Remote.FEATURE_KEY != 0
    val supportsIme get() = activeFeatures and Remote.FEATURE_IME != 0
}

/** جلسة تحكم (المنفذ 6466) بعد الاقتران. */
class RemoteClient(
    private val identity: ClientIdentity,
    private val pinnedFingerprint: String?,
    private val listener: Listener,
) : Closeable {

    interface Listener {
        fun onLog(line: String)
        fun onImeUpdate(state: ImeState)
        fun onClosed(reason: String?)
    }

    private var conn: Tls.Connection? = null
    private val writeLock = Any()

    @Volatile var info: RemoteInfo? = null
        private set
    @Volatile var ime: ImeState = ImeState()
        private set
    @Volatile private var closed = false
    @Volatile private var hasImeCounter = false
    @Volatile private var hasFieldCounter = false
    private val readyLatch = CountDownLatch(1)
    @Volatile private var failure: String? = null

    /** يتصل وينتظر remote_start من التلفزيون. يرمي استثناءً بسبب مفهوم عند الفشل. */
    fun connect(host: String, port: Int = Tls.REMOTE_PORT, readyTimeoutMs: Long = 10000): RemoteInfo {
        val c = try {
            Tls.connect(host, port, identity, pinnedFingerprint, 4000, 30000)
        } catch (e: Exception) {
            throw IOException("تعذّر الاتصال بمنفذ التحكم: ${describeNetworkError(e)}", e)
        }
        conn = c
        val t = Thread({ readLoop(c) }, "atv-remote-reader")
        t.isDaemon = true
        t.start()
        if (!readyLatch.await(readyTimeoutMs, TimeUnit.MILLISECONDS)) {
            val why = failure ?: "لم يرسل التلفزيون إشارة الجاهزية خلال ${readyTimeoutMs / 1000} ثوانٍ"
            close()
            throw IOException(why)
        }
        failure?.let { close(); throw IOException(it) }
        return info ?: RemoteInfo("", "", "", 0, 0)
    }

    private fun readLoop(c: Tls.Connection) {
        var reason: String? = null
        try {
            val input = c.socket.inputStream
            while (!closed) {
                val raw = Frames.read(input) ?: break
                handle(Remote.parse(raw))
            }
        } catch (e: Exception) {
            if (!closed) reason = describeNetworkError(e)
        } finally {
            if (!closed) {
                if (failure == null && readyLatch.count > 0) {
                    failure = reason?.let { "أُغلق الاتصال قبل الجاهزية ($it) — غالباً يلزم الاقتران أولاً" }
                        ?: "أغلق التلفزيون الاتصال قبل الجاهزية — غالباً يلزم الاقتران أولاً"
                }
                readyLatch.countDown()
                closed = true
                listener.onClosed(reason)
            }
        }
    }

    private fun handle(m: Remote.Incoming) {
        when (m) {
            is Remote.Incoming.Configure -> {
                val active = Remote.DESIRED_FEATURES and m.supportedFeatures
                info = RemoteInfo(m.vendor, m.model, m.appVersion, m.supportedFeatures, active)
                listener.onLog("التلفزيون: ${m.vendor} ${m.model} · الميزات المدعومة=${m.supportedFeatures} · المفعّلة=$active")
                send(Remote.configureReply(active))
            }
            is Remote.Incoming.SetActive -> send(Remote.setActive(info?.activeFeatures ?: Remote.DESIRED_FEATURES))
            is Remote.Incoming.Ping -> send(Remote.pingResponse(m.val1))
            is Remote.Incoming.Start -> {
                listener.onLog("remote_start: started=${m.started}")
                readyLatch.countDown()
            }
            is Remote.Incoming.ImeKeyInject -> {
                hasImeCounter = m.imeCounter != 0
                hasFieldCounter = m.fieldCounter != 0
                update(ImeState(m.hasFieldStatus, m.appPackage, m.appLabel, m.imeCounter, m.fieldCounter, m.value, System.currentTimeMillis()))
            }
            is Remote.Incoming.ImeShowRequest -> {
                if (m.hasFieldStatus) {
                    hasFieldCounter = true
                    update(ime.copy(hasFieldStatus = true, fieldCounter = m.fieldCounter, value = m.value, updatedAtMs = System.currentTimeMillis()))
                }
            }
            is Remote.Incoming.ImeBatchEdit -> {
                var s = ime
                if (!hasImeCounter) s = s.copy(imeCounter = m.imeCounter)
                if (!hasFieldCounter) s = s.copy(fieldCounter = m.fieldCounter)
                update(s.copy(updatedAtMs = System.currentTimeMillis()))
            }
            is Remote.Incoming.Error -> listener.onLog("remote_error من التلفزيون")
            is Remote.Incoming.Volume -> Unit
            is Remote.Incoming.Unknown -> listener.onLog("رسالة غير معروفة من التلفزيون: الحقول ${m.fieldNumbers}")
        }
    }

    private fun update(s: ImeState) {
        ime = s
        listener.onImeUpdate(s)
    }

    private fun send(msg: ByteArray) {
        val c = conn ?: return
        synchronized(writeLock) {
            try {
                Frames.write(c.socket.outputStream, msg)
            } catch (e: IOException) {
                if (!closed) listener.onLog("تعذّر الإرسال: ${describeNetworkError(e)}")
            }
        }
    }

    private val allowedKeys = setOf(
        Remote.KEYCODE_HOME, Remote.KEYCODE_BACK, Remote.KEYCODE_DPAD_UP, Remote.KEYCODE_DPAD_DOWN,
        Remote.KEYCODE_DPAD_LEFT, Remote.KEYCODE_DPAD_RIGHT, Remote.KEYCODE_DPAD_CENTER,
    )

    /** زر ريموت واحد. قائمة الأزرار المسموحة مقيّدة؛ لا يوجد Enter. يُستدعى من ضغطة يدوية فقط. */
    fun sendKey(keyCode: Int) {
        check(!closed) { "الاتصال مغلق" }
        require(keyCode in allowedKeys) { "زر غير مسموح" }
        send(Remote.keyInject(keyCode))
    }

    /** يدرج نصاً في الحقل المركّز. لا يضغط إرسال/Enter. يعيد وصف العدادات المستخدمة للسجل. */
    fun sendText(text: String): String {
        check(!closed) { "الاتصال مغلق" }
        require(text.isNotEmpty()) { "النص فارغ" }
        require('\n' !in text && '\r' !in text) { "ممنوع إدخال أسطر جديدة (قد تُرسل الأمر)" }
        check(info?.supportsIme == true) { "التلفزيون لم يفعّل ميزة الإدخال النصي (IME)" }
        val s = ime
        send(Remote.imeInsertText(s.imeCounter, s.fieldCounter, text))
        return "ime_counter=${s.imeCounter}, field_counter=${s.fieldCounter}"
    }

    val isOpen get() = !closed

    override fun close() {
        closed = true
        conn?.close()
        conn = null
        readyLatch.countDown()
    }
}
