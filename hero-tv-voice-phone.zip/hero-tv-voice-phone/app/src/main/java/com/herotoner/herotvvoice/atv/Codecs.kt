package com.herotoner.herotvvoice.atv

/**
 * رسائل بروتوكول الاقتران (Polo، المنفذ 6467) وبروتوكول التحكم (Remote v2، المنفذ 6466).
 * أرقام الحقول مطابقة لتعريفات المشروع المفتوح androidtvremote2 (Apache-2.0) الذي استُخدم مرجعاً
 * للتحقق فقط؛ الكود هنا مكتوب من جديد.
 * ملاحظة: البروتوكول غير موثّق رسمياً من Google وقد يتغير.
 */
object Polo {
    const val STATUS_OK = 200
    const val STATUS_ERROR = 400
    const val STATUS_BAD_CONFIGURATION = 401
    const val STATUS_BAD_SECRET = 402

    private const val PROTOCOL_VERSION = 2
    private const val ENCODING_HEX = 3
    private const val SYMBOL_LENGTH = 6
    private const val ROLE_INPUT = 1

    private fun outer(payload: ProtoWriter.() -> Unit): ByteArray =
        ProtoWriter().int32(1, PROTOCOL_VERSION).int32(2, STATUS_OK).apply(payload).toByteArray()

    fun pairingRequest(serviceName: String, clientName: String): ByteArray = outer {
        message(10) {
            string(1, serviceName)
            string(2, clientName)
        }
    }

    fun options(): ByteArray = outer {
        message(20) {
            message(1) { int32(1, ENCODING_HEX); int32(2, SYMBOL_LENGTH) } // input_encodings
            int32(3, ROLE_INPUT) // preferred_role
        }
    }

    fun configuration(): ByteArray = outer {
        message(30) {
            message(1) { int32(1, ENCODING_HEX); int32(2, SYMBOL_LENGTH) } // encoding
            int32(2, ROLE_INPUT) // client_role
        }
    }

    fun secret(secret: ByteArray): ByteArray = outer { message(40) { bytes(1, secret) } }

    enum class Kind { PAIRING_REQUEST_ACK, OPTIONS, CONFIGURATION_ACK, SECRET_ACK, OTHER }

    class Incoming(val status: Int, val kind: Kind, val serverName: String = "")

    fun parse(data: ByteArray): Incoming {
        val f = ProtoReader.parse(data)
        val status = f.intOf(2)
        val kind = when {
            f.hasField(11) -> Kind.PAIRING_REQUEST_ACK
            f.hasField(20) -> Kind.OPTIONS
            f.hasField(31) -> Kind.CONFIGURATION_ACK
            f.hasField(41) -> Kind.SECRET_ACK
            else -> Kind.OTHER
        }
        val name = f.bytesOf(11)?.let { ProtoReader.parse(it).stringOf(1) } ?: ""
        return Incoming(status, kind, name)
    }
}

object Remote {
    // أعلام الميزات (code1)
    const val FEATURE_PING = 1
    const val FEATURE_KEY = 2
    const val FEATURE_IME = 4
    const val FEATURE_POWER = 32
    const val FEATURE_VOLUME = 64
    const val FEATURE_APP_LINK = 512

    /** نفس الميزات الافتراضية للمرجع بدون الصوت. تُقاطَع مع ما يدعمه التلفزيون فعلاً. */
    const val DESIRED_FEATURES =
        FEATURE_PING or FEATURE_KEY or FEATURE_IME or FEATURE_POWER or FEATURE_VOLUME or FEATURE_APP_LINK

    const val KEYCODE_HOME = 3
    const val KEYCODE_BACK = 4
    const val KEYCODE_DPAD_UP = 19
    const val KEYCODE_DPAD_DOWN = 20
    const val KEYCODE_DPAD_LEFT = 21
    const val KEYCODE_DPAD_RIGHT = 22
    const val KEYCODE_DPAD_CENTER = 23

    const val DIRECTION_SHORT = 3

    fun configureReply(activeFeatures: Int): ByteArray = ProtoWriter().message(1) {
        int32(1, activeFeatures)
        message(2) {
            int32(3, 1)
            string(4, "1")
            string(5, "atvremote")
            string(6, "1.0.0")
        }
    }.toByteArray()

    fun setActive(activeFeatures: Int): ByteArray =
        ProtoWriter().message(2) { int32(1, activeFeatures) }.toByteArray()

    fun pingResponse(val1: Int): ByteArray =
        ProtoWriter().message(9) { int32(1, val1) }.toByteArray()

    fun keyInject(keyCode: Int): ByteArray =
        ProtoWriter().message(10) {
            int32(1, keyCode)
            int32(2, DIRECTION_SHORT)
        }.toByteArray()

    /** إدراج نص عند المؤشر (insert=1) في الحقل المركّز؛ المؤشر يبقى بعد النص. لا يُرسل أي زر Enter. */
    fun imeInsertText(imeCounter: Int, fieldCounter: Int, text: String): ByteArray {
        val len = text.codePointCount(0, text.length)
        return ProtoWriter().message(21) {
            int32(1, imeCounter)
            int32(2, fieldCounter)
            message(3) {
                int32(1, 1)
                message(2) {
                    int32(1, len)
                    int32(2, len)
                    string(3, text)
                }
            }
        }.toByteArray()
    }

    sealed interface Incoming {
        class Configure(val supportedFeatures: Int, val vendor: String, val model: String, val appVersion: String) : Incoming
        class SetActive(val value: Int) : Incoming
        class Ping(val val1: Int) : Incoming
        class Start(val started: Boolean) : Incoming
        class ImeKeyInject(
            val appPackage: String,
            val appLabel: String,
            val imeCounter: Int,
            val fieldCounter: Int,
            val value: String,
            val start: Int,
            val end: Int,
            val hasFieldStatus: Boolean,
        ) : Incoming
        class ImeShowRequest(val fieldCounter: Int, val value: String, val hasFieldStatus: Boolean) : Incoming
        class ImeBatchEdit(val imeCounter: Int, val fieldCounter: Int) : Incoming
        class Error(val flag: Boolean) : Incoming
        class Volume(val level: Int, val max: Int, val muted: Boolean) : Incoming
        class Unknown(val fieldNumbers: List<Int>) : Incoming
    }

    fun parse(data: ByteArray): Incoming {
        val f = ProtoReader.parse(data)
        f.bytesOf(1)?.let { b ->
            val c = ProtoReader.parse(b)
            val d = c.bytesOf(2)?.let { ProtoReader.parse(it) } ?: emptyList()
            return Incoming.Configure(c.intOf(1), d.stringOf(2), d.stringOf(1), d.stringOf(6))
        }
        f.bytesOf(2)?.let { return Incoming.SetActive(ProtoReader.parse(it).intOf(1)) }
        f.bytesOf(3)?.let { return Incoming.Error(ProtoReader.parse(it).boolOf(1)) }
        f.bytesOf(8)?.let { return Incoming.Ping(ProtoReader.parse(it).intOf(1)) }
        f.bytesOf(20)?.let { b ->
            val m = ProtoReader.parse(b)
            val app = m.bytesOf(1)?.let { ProtoReader.parse(it) } ?: emptyList()
            val tfBytes = m.bytesOf(2)
            val tf = tfBytes?.let { ProtoReader.parse(it) } ?: emptyList()
            return Incoming.ImeKeyInject(
                appPackage = app.stringOf(12),
                appLabel = app.stringOf(10),
                imeCounter = app.intOf(1),
                fieldCounter = tf.intOf(1),
                value = tf.stringOf(2),
                start = tf.intOf(3),
                end = tf.intOf(4),
                hasFieldStatus = tfBytes != null,
            )
        }
        f.bytesOf(21)?.let { b ->
            val m = ProtoReader.parse(b)
            return Incoming.ImeBatchEdit(m.intOf(1), m.intOf(2))
        }
        f.bytesOf(22)?.let { b ->
            val m = ProtoReader.parse(b)
            val tfBytes = m.bytesOf(2)
            val tf = tfBytes?.let { ProtoReader.parse(it) } ?: emptyList()
            return Incoming.ImeShowRequest(tf.intOf(1), tf.stringOf(2), tfBytes != null)
        }
        f.bytesOf(40)?.let { return Incoming.Start(ProtoReader.parse(it).boolOf(1)) }
        f.bytesOf(50)?.let {
            val v = ProtoReader.parse(it)
            return Incoming.Volume(v.intOf(7), v.intOf(6), v.boolOf(8))
        }
        return Incoming.Unknown(f.map { it.number })
    }
}
