package com.herotoner.herotvvoice.command

/**
 * هل الأمر ضمن "مفردات" الأوامر التي يتحقق منها تطبيق التلفزيون المفحوص
 * (com.tvai.assistant.next v0.7.2 — الأحدث المفحوص؛ المدقّق مطابق لما في v0.6.9.
 * انظر docs/PHASE0_TV_APP_INSPECTION.md)؟
 * هذا مجرد وصف لما وُجد في ملف APK، وليس ضماناً بأن التلفزيون سينفّذه.
 */
enum class TvSupport {
    /** الاسم موجود في قائمة الأوامر المسموحة داخل CompanionCommandValidator. */
    IN_TV_VALIDATOR_VOCABULARY,

    /** غير موجود في تلك القائمة — يحتاج دعماً جديداً من جهة التلفزيون. */
    NOT_IN_TV_VOCABULARY,
}

enum class TvAction(
    val wireName: String,
    val label: String,
    val tvSupport: TvSupport,
) {
    UP("up", "انتقل للأعلى", TvSupport.IN_TV_VALIDATOR_VOCABULARY),
    DOWN("down", "انتقل للأسفل", TvSupport.IN_TV_VALIDATOR_VOCABULARY),
    LEFT("left", "انتقل لليسار", TvSupport.IN_TV_VALIDATOR_VOCABULARY),
    RIGHT("right", "انتقل لليمين", TvSupport.IN_TV_VALIDATOR_VOCABULARY),
    SELECT("ok", "اختر العنصر المحدد", TvSupport.IN_TV_VALIDATOR_VOCABULARY),
    BACK("back", "ارجع للخلف", TvSupport.IN_TV_VALIDATOR_VOCABULARY),
    HOME("home", "ارجع إلى الشاشة الرئيسية", TvSupport.IN_TV_VALIDATOR_VOCABULARY),
    VOLUME_UP("volume_up", "ارفع الصوت", TvSupport.IN_TV_VALIDATOR_VOCABULARY),
    VOLUME_DOWN("volume_down", "اخفض الصوت", TvSupport.IN_TV_VALIDATOR_VOCABULARY),
    MUTE("mute", "اكتم الصوت", TvSupport.IN_TV_VALIDATOR_VOCABULARY),
    OPEN_SETTINGS("open_settings", "افتح الإعدادات", TvSupport.NOT_IN_TV_VOCABULARY),
    OPEN_APP("open_app", "افتح تطبيقاً", TvSupport.NOT_IN_TV_VOCABULARY),
}

data class ParsedCommand(
    val action: TvAction,
    val arg: String? = null,
) {
    val displayLabel: String
        get() = if (arg != null) "${action.label}: $arg" else action.label
}

/**
 * أمر ينتظر موافقة المستخدم. [requestId] عشوائي وفريد لكل أمر ليُستخدم لاحقاً
 * (المرحلة 2) في منع إعادة الإرسال/التكرار غير المقصود.
 */
data class PendingCommand(
    val requestId: String,
    val command: ParsedCommand,
    val spokenText: String,
    val createdAtMs: Long,
)
