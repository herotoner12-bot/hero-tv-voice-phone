package com.herotoner.herotvvoice.ui

import androidx.annotation.StringRes
import com.herotoner.herotvvoice.command.PendingCommand

sealed interface UiState {
    data object Idle : UiState
    data object Listening : UiState
    data object Processing : UiState
    data object Cancelled : UiState
    data class Understood(val transcript: String, val pending: PendingCommand) : UiState
    data class NotUnderstood(val transcript: String) : UiState
    data class Failed(@StringRes val messageRes: Int, val offerAppSettings: Boolean = false) : UiState
}
