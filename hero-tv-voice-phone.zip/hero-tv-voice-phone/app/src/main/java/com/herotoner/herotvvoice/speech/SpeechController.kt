package com.herotoner.herotvvoice.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

enum class SpeechFailure {
    NO_SPEECH,
    NETWORK,
    PERMISSION,
    BUSY,
    LANGUAGE_UNAVAILABLE,
    AUDIO,
    SERVER,
    OTHER,
}

/**
 * غلاف رفيع حول [SpeechRecognizer] الخاص بنظام Android. يستخدم ميكروفون الهاتف الافتراضي فقط.
 * التطبيق نفسه لا يسجّل الصوت ولا يخزّنه ولا يرسله؛ التعرف يتم عبر خدمة التعرف المثبتة على الهاتف.
 * كل النداءات الراجعة تصل على الخيط الرئيسي.
 */
class SpeechController(
    private val context: Context,
    private val listener: Listener,
) {
    interface Listener {
        fun onSpeechBegin()
        fun onLevel(rmsDb: Float)
        fun onPartial(text: String)
        fun onResults(alternatives: List<String>)
        fun onFailure(failure: SpeechFailure)
    }

    private var recognizer: SpeechRecognizer? = null
    private var generation = 0

    var isActive: Boolean = false
        private set

    fun start(preferOffline: Boolean) {
        if (isActive) return
        release()
        val myGeneration = ++generation
        val r = SpeechRecognizer.createSpeechRecognizer(context)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {
                if (myGeneration == generation) listener.onSpeechBegin()
            }

            override fun onRmsChanged(rmsdB: Float) {
                if (myGeneration == generation) listener.onLevel(rmsdB)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onError(error: Int) {
                if (myGeneration != generation) return
                isActive = false
                listener.onFailure(mapError(error))
            }

            override fun onPartialResults(partialResults: Bundle?) {
                if (myGeneration != generation) return
                val text = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!text.isNullOrBlank()) listener.onPartial(text)
            }

            override fun onResults(results: Bundle?) {
                if (myGeneration != generation) return
                isActive = false
                val list = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.filter { it.isNotBlank() }
                    .orEmpty()
                listener.onResults(list)
            }
        })
        recognizer = r
        isActive = true

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, LANGUAGE_TAG)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, LANGUAGE_TAG)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }
        r.startListening(intent)
    }

    /** إنهاء الاستماع وطلب النتيجة النهائية. */
    fun stop() {
        recognizer?.stopListening()
    }

    /** إلغاء كامل بلا نتيجة. */
    fun cancel() {
        release()
    }

    fun release() {
        generation++ // يُبطل أي نداء متأخر من الجلسة السابقة
        isActive = false
        recognizer?.let {
            try {
                it.cancel()
            } catch (_: Exception) {
            }
            it.destroy()
        }
        recognizer = null
    }

    private fun mapError(code: Int): SpeechFailure = when (code) {
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT,
        SpeechRecognizer.ERROR_NO_MATCH -> SpeechFailure.NO_SPEECH

        SpeechRecognizer.ERROR_NETWORK,
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> SpeechFailure.NETWORK

        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> SpeechFailure.PERMISSION
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
        SpeechRecognizer.ERROR_TOO_MANY_REQUESTS -> SpeechFailure.BUSY

        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED,
        SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> SpeechFailure.LANGUAGE_UNAVAILABLE

        SpeechRecognizer.ERROR_AUDIO -> SpeechFailure.AUDIO
        SpeechRecognizer.ERROR_SERVER,
        SpeechRecognizer.ERROR_SERVER_DISCONNECTED -> SpeechFailure.SERVER

        else -> SpeechFailure.OTHER
    }

    companion object {
        const val LANGUAGE_TAG = "ar-SA"

        fun isAvailable(context: Context): Boolean = SpeechRecognizer.isRecognitionAvailable(context)
    }
}
