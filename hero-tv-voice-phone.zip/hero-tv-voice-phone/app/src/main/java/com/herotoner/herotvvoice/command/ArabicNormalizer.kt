package com.herotoner.herotvvoice.command

/**
 * توحيد النص العربي قبل المطابقة: إزالة التشكيل والتطويل، توحيد الهمزات والياء والتاء المربوطة،
 * وإزالة علامات الترقيم. كود Kotlin صرف (لا يعتمد على Android) ليسهل اختباره.
 */
object ArabicNormalizer {
    private val DIACRITICS = Regex("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]")
    private val PUNCTUATION = Regex("[\\p{Punct}\\u060C\\u061B\\u061F]")
    private val SPACES = Regex("\\s+")

    fun normalize(input: String): String {
        var t = input.lowercase()
        t = DIACRITICS.replace(t, "")
        t = t.replace("ـ", "") // التطويل
        t = t.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ٱ', 'ا')
        t = t.replace('ى', 'ي').replace('ئ', 'ي').replace('ؤ', 'و').replace('ة', 'ه')
        t = PUNCTUATION.replace(t, " ")
        t = SPACES.replace(t, " ")
        return t.trim()
    }
}
