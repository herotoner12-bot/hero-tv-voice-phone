package com.herotoner.herotvvoice.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.herotoner.herotvvoice.R
import com.herotoner.herotvvoice.atv.AndroidIdentityStore
import com.herotoner.herotvvoice.atv.ClientIdentity
import com.herotoner.herotvvoice.atv.ImeState
import com.herotoner.herotvvoice.atv.NsdDiscovery
import com.herotoner.herotvvoice.atv.PairingClient
import com.herotoner.herotvvoice.atv.PairingException
import com.herotoner.herotvvoice.atv.PortProbe
import com.herotoner.herotvvoice.atv.Remote
import com.herotoner.herotvvoice.atv.RemoteClient
import com.herotoner.herotvvoice.atv.Tls
import com.herotoner.herotvvoice.atv.loadOrCreate
import com.herotoner.herotvvoice.databinding.ActivityDiagnosticsBinding
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * فحص تشخيصي فقط لإمكانية إرسال نص عربي إلى حقل الكتابة المركّز على التلفزيون عبر
 * خدمة Android TV Remote المدمجة في النظام. لا ADB، ولا تعديل لتطبيق التلفزيون،
 * ولا إرسال تلقائي لزر Enter/إرسال. نتيجة اختبار النص تعتمد على تأكيد المستخدم لما رآه على الشاشة.
 */
class DiagnosticsActivity : AppCompatActivity(), RemoteClient.Listener, NsdDiscovery.Callback {

    private lateinit var b: ActivityDiagnosticsBinding
    private lateinit var prefs: SharedPreferences
    private lateinit var store: AndroidIdentityStore

    private val io = Executors.newSingleThreadExecutor()
    private val working = AtomicBoolean(false)
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Volatile private var identity: ClientIdentity? = null
    @Volatile private var remote: RemoteClient? = null
    @Volatile private var pairing: PairingClient? = null
    @Volatile private var pairingHost: String? = null
    private var nsd: NsdDiscovery? = null
    private val discovered = LinkedHashSet<String>()

    // سجل التقرير (يُعدَّل على الخيط الرئيسي فقط)
    private val report = StringBuilder()

    // ملخص النتائج (للتقرير)
    private var tcp6467: Boolean? = null
    private var tcp6466: Boolean? = null
    private var paired = false
    private var connected = false
    private var deviceInfo = ""
    @Volatile private var focusedPackage = ""
    private var textSent: String? = null
    private var echoMatched: Boolean? = null
    private var verdict = "لم يُسجَّل بعد"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityDiagnosticsBinding.inflate(layoutInflater)
        setContentView(b.root)
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        store = AndroidIdentityStore(this)

        b.hostInput.setText(prefs.getString(KEY_HOST, "") ?: "")
        setConnectedUi(false)

        b.discoverButton.setOnClickListener { toggleDiscovery() }
        b.probeButton.setOnClickListener { readHost()?.let { h -> job("جارٍ فحص المنفذين…") { runProbe(h) } } }
        b.pairStartButton.setOnClickListener { readHost()?.let { h -> job("جارٍ بدء الاقتران…") { startPairing(h) } } }
        b.pairFinishButton.setOnClickListener { finishPairing() }
        b.resetIdentityButton.setOnClickListener { job("جارٍ المسح…") { resetIdentity() } }
        b.connectButton.setOnClickListener { readHost()?.let { h -> job("جارٍ الاتصال…") { connectRemote(h) } } }
        b.sendTextButton.setOnClickListener { sendTestText() }
        b.keyUp.setOnClickListener { manualKey(Remote.KEYCODE_DPAD_UP, "▲") }
        b.keyDown.setOnClickListener { manualKey(Remote.KEYCODE_DPAD_DOWN, "▼") }
        b.keyLeft.setOnClickListener { manualKey(Remote.KEYCODE_DPAD_LEFT, "◀") }
        b.keyRight.setOnClickListener { manualKey(Remote.KEYCODE_DPAD_RIGHT, "▶") }
        b.keyOk.setOnClickListener { manualKey(Remote.KEYCODE_DPAD_CENTER, "OK") }
        b.keyBack.setOnClickListener { manualKey(Remote.KEYCODE_BACK, "رجوع") }
        b.verdictOk.setOnClickListener { setVerdict("نجح: ظهر النص العربي صحيحاً في الحقل (بتأكيد المستخدم)") }
        b.verdictGarbled.setOnClickListener { setVerdict("فشل جزئي: ظهر النص مشوّهاً أو ناقصاً (بتأكيد المستخدم)") }
        b.verdictNone.setOnClickListener { setVerdict("فشل: لم يظهر شيء في الحقل (بتأكيد المستخدم)") }
        b.copyReportButton.setOnClickListener { copyReport() }

        log("بدأ الفحص — Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) · ${Build.MANUFACTURER} ${Build.MODEL}")
    }

    override fun onDestroy() {
        nsd?.stop()
        remote?.close()
        pairing?.close()
        io.shutdownNow()
        super.onDestroy()
    }

    // ------------------------------------------------------------------ أدوات

    private fun log(line: String) {
        runOnUiThread {
            report.append('[').append(timeFmt.format(Date())).append("] ").append(line).append('\n')
            b.reportText.text = report
        }
    }

    private fun ui(block: () -> Unit) = runOnUiThread(block)

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun job(label: String, body: () -> Unit) {
        if (!working.compareAndSet(false, true)) {
            toast(getString(R.string.diag_busy))
            return
        }
        b.workingText.text = label
        b.workingText.visibility = View.VISIBLE
        io.execute {
            try {
                body()
            } catch (e: Exception) {
                log("خطأ غير متوقع: ${e.javaClass.simpleName}: ${e.message}")
            } finally {
                working.set(false)
                ui { b.workingText.visibility = View.GONE }
            }
        }
    }

    private fun readHost(): String? {
        val h = b.hostInput.text.toString().trim()
        if (!isPrivateIpv4(h)) {
            toast(getString(R.string.diag_host_invalid))
            return null
        }
        prefs.edit().putString(KEY_HOST, h).apply()
        return h
    }

    private fun fpKey(host: String) = "fp_$host"

    private fun ensureIdentity(): ClientIdentity {
        identity?.let { return it }
        log("جارٍ تجهيز هوية الهاتف (توليد مفتاح RSA قد يستغرق عدة ثوانٍ)…")
        return store.loadOrCreate().also { identity = it }
    }

    // ------------------------------------------------------------------ 1) الاكتشاف

    private fun toggleDiscovery() {
        val current = nsd
        if (current != null && current.isRunning) {
            current.stop()
            return
        }
        discovered.clear()
        b.discoveryList.removeAllViews()
        b.discoveryStatus.text = "جارٍ البحث عن _androidtvremote2._tcp …"
        val d = NsdDiscovery(this, this)
        nsd = d
        d.start()
    }

    override fun onFound(name: String, host: String, port: Int) {
        if (!discovered.add(host)) return
        log("اكتُشف: $name — $host:$port")
        val btn = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle)
        btn.text = "$name — $host"
        btn.setOnClickListener { b.hostInput.setText(host) }
        b.discoveryList.addView(btn)
    }

    override fun onStopped(foundCount: Int) {
        b.discoveryStatus.text = if (foundCount > 0) "انتهى البحث: عُثر على $foundCount. اضغط على الجهاز لاختياره."
        else getString(R.string.diag_no_host_found)
        log("انتهى البحث: $foundCount جهاز")
    }

    // ------------------------------------------------------------------ 2) فحص المنافذ

    private fun runProbe(host: String) {
        log("فحص $host")
        val t6467 = PortProbe.tcp(host, Tls.PAIRING_PORT)
        val t6466 = PortProbe.tcp(host, Tls.REMOTE_PORT)
        tcp6467 = t6467.open
        tcp6466 = t6466.open
        log("TCP 6467: ${if (t6467.open) "مفتوح" else "غير متاح — ${t6467.error}"} (${t6467.millis}ms)")
        log("TCP 6466: ${if (t6466.open) "مفتوح" else "غير متاح — ${t6466.error}"} (${t6466.millis}ms)")
        val id = ensureIdentity()
        val tls6467 = if (t6467.open) PortProbe.tls(host, Tls.PAIRING_PORT, id) else null
        val tls6466 = if (t6466.open) PortProbe.tls(host, Tls.REMOTE_PORT, id) else null
        tls6467?.let { log("TLS 6467: ${if (it.ok) "نجحت المصافحة — ${it.subject} — ${it.fingerprint?.take(23)}…" else "فشلت — ${it.error}"}") }
        tls6466?.let { log("TLS 6466: ${if (it.ok) "نجحت المصافحة (قبول الجلسة يتطلب اقتراناً سابقاً)" else "فشلت — ${it.error}"}") }

        val sb = StringBuilder()
        sb.append("المنفذ 6467 (الاقتران): ").append(if (t6467.open) "مفتوح" else "غير متاح (${t6467.error})").appendLine()
        sb.append("المنفذ 6466 (التحكم): ").append(if (t6466.open) "مفتوح" else "غير متاح (${t6466.error})").appendLine()
        sb.append("مصافحة TLS على 6467: ").append(
            when {
                tls6467 == null -> "لم تُجرَّ"
                tls6467.ok -> "نجحت"
                else -> "فشلت (${tls6467.error})"
            }
        ).appendLine().appendLine()
        sb.append(
            when {
                t6467.open && t6466.open -> "الخلاصة: خدمة Android TV Remote تبدو متاحة. هذا لا يثبت أن إرسال النص سيعمل — الحسم في الخطوة 5."
                else -> "الخلاصة: الخدمة غير متاحة على هذا العنوان. تحقق من العنوان ومن أن الهاتف والتلفزيون على الشبكة نفسها، وأن خدمة Android TV Remote Service مفعّلة على التلفزيون."
            }
        )
        ui { b.probeResult.text = sb.toString() }
    }

    // ------------------------------------------------------------------ 3) الاقتران

    private fun startPairing(host: String) {
        val id = ensureIdentity()
        pairing?.close()
        val pc = PairingClient(id)
        try {
            val fp = pc.start(host)
            pairing = pc
            pairingHost = host
            log("بدأ الاقتران؛ بصمة شهادة التلفزيون: ${fp.take(23)}… — أدخل الرمز الظاهر على التلفزيون")
            ui {
                b.pinGroup.visibility = View.VISIBLE
                b.pinInput.setText("")
                b.pairStatus.text = "أدخل الرمز الظاهر على شاشة التلفزيون ثم اضغط «أكمل الاقتران»."
            }
        } catch (e: PairingException) {
            pc.close()
            log("فشل بدء الاقتران: ${e.message}")
            ui { b.pairStatus.text = "فشل بدء الاقتران: ${e.message}" }
        }
    }

    private fun finishPairing() {
        val pc = pairing
        val host = pairingHost
        if (pc == null || host == null) {
            toast("ابدأ الاقتران أولاً")
            return
        }
        val pin = b.pinInput.text.toString()
        job("جارٍ إكمال الاقتران…") {
            try {
                val fp = pc.finish(pin)
                prefs.edit().putString(fpKey(host), fp).apply()
                paired = true
                pairing = null
                log("تم الاقتران مع $host؛ ثُبّتت بصمة شهادة التلفزيون ${fp.take(23)}…")
                ui {
                    b.pinGroup.visibility = View.GONE
                    b.pairStatus.text = "تم الاقتران بنجاح. انتقل إلى الخطوة 4."
                }
            } catch (e: PairingException) {
                log("فشل إكمال الاقتران: ${e.message}")
                if (!pc.isConnected) {
                    pairing = null
                    ui {
                        b.pinGroup.visibility = View.GONE
                        b.pairStatus.text = "فشل الاقتران: ${e.message}. ابدأ الاقتران من جديد."
                    }
                } else {
                    ui { b.pairStatus.text = "${e.message}. صحّح الرمز وأعد المحاولة." }
                }
            }
        }
    }

    private fun resetIdentity() {
        remote?.close(); remote = null
        pairing?.close(); pairing = null
        store.clear()
        identity = null
        val ed = prefs.edit()
        prefs.all.keys.filter { it.startsWith("fp_") }.forEach { ed.remove(it) }
        ed.apply()
        paired = false
        connected = false
        log("مُسحت هوية الهاتف والبصمات المثبتة. (أزل HERO TV VOICE أيضاً من «أجهزة الريموت» في إعدادات التلفزيون إن وُجد.)")
        ui {
            setConnectedUi(false)
            b.pinGroup.visibility = View.GONE
            b.pairStatus.text = "تم المسح. يلزم اقتران جديد."
            b.connectStatus.text = ""
        }
    }

    // ------------------------------------------------------------------ 4) التحكم

    private fun connectRemote(host: String) {
        val fp = prefs.getString(fpKey(host), null)
        if (fp == null) {
            log("لا توجد بصمة مثبتة للعنوان $host — اقترن أولاً")
            ui { b.connectStatus.text = "لا يوجد اقتران مسجّل لهذا العنوان. نفّذ الخطوة 3 أولاً." }
            return
        }
        remote?.close()
        val id = ensureIdentity()
        val rc = RemoteClient(id, fp, this)
        try {
            val info = rc.connect(host)
            remote = rc
            connected = true
            deviceInfo = "${info.vendor} ${info.model} (v${info.appVersion})".trim()
            log("متصل بخدمة التحكم. الجهاز: $deviceInfo · IME=${info.supportsIme} · KEY=${info.supportsKeys}")
            ui {
                setConnectedUi(true)
                b.connectStatus.text = "متصل: $deviceInfo\nالإدخال النصي (IME): ${if (info.supportsIme) "مفعّل" else "غير مدعوم من التلفزيون"}"
            }
        } catch (e: IOException) {
            rc.close()
            connected = false
            log("فشل الاتصال بخدمة التحكم: ${e.message}")
            ui {
                setConnectedUi(false)
                b.connectStatus.text = "فشل الاتصال: ${e.message}"
            }
        }
    }

    private fun setConnectedUi(on: Boolean) {
        listOf(b.keyUp, b.keyDown, b.keyLeft, b.keyRight, b.keyOk, b.keyBack, b.sendTextButton).forEach { it.isEnabled = on }
        if (!on) b.imeStatus.text = ""
    }

    private fun manualKey(code: Int, label: String) {
        val rc = remote?.takeIf { it.isOpen } ?: run { toast("غير متصل"); return }
        io.execute {
            try {
                rc.sendKey(code)
                log("ضغطة يدوية: $label")
            } catch (e: Exception) {
                log("تعذّر إرسال الزر: ${e.message}")
            }
        }
    }

    // RemoteClient.Listener + NsdDiscovery.Callback (نفس التوقيع)
    override fun onLog(line: String) = log(line)

    override fun onImeUpdate(state: ImeState) {
        val isMohamed = state.appPackage == MOHAMED_PKG
        if (state.appPackage != focusedPackage) {
            focusedPackage = state.appPackage
            log("حقل الكتابة المركّز: ${state.appPackage.ifEmpty { "(غير معروف)" }}${if (isMohamed) " ← هو Mohamed TV AI Assistant" else ""}")
        }
        ui {
            b.imeStatus.text = if (state.hasFieldStatus) {
                "حقل كتابة مركّز على التلفزيون: نعم\n" +
                    "التطبيق: ${state.appPackage.ifEmpty { "؟" }}${if (isMohamed) " ✓ (Mohamed TV AI Assistant)" else ""}\n" +
                    "القيمة الحالية في الحقل: «${state.value}»"
            } else {
                "لم يُبلغ التلفزيون عن حقل كتابة مركّز بعد. حرّك التركيز إلى الحقل بالأزرار أعلاه."
            }
        }
    }

    override fun onClosed(reason: String?) {
        connected = false
        log("أُغلق اتصال التحكم${reason?.let { ": $it" } ?: ""}")
        ui { setConnectedUi(false); b.connectStatus.text = "انقطع الاتصال. اضغط «اتصل بخدمة التحكم» للمحاولة مجدداً." }
    }

    // ------------------------------------------------------------------ 5) النص العربي

    private fun sendTestText() {
        val rc = remote?.takeIf { it.isOpen } ?: run { toast("غير متصل"); return }
        val text = b.testTextInput.text.toString().trim()
        if (text.isEmpty()) {
            toast("اكتب نصاً تجريبياً")
            return
        }
        job("جارٍ إدراج النص…") {
            try {
                val used = rc.sendText(text)
                textSent = text
                echoMatched = null
                log("أُرسل نص تجريبي (${text.length} حرفاً): «$text» — $used — دون أي زر إرسال")
                ui { b.echoStatus.text = "أُرسل النص. بانتظار صدى التلفزيون…"; b.verdictGroup.visibility = View.GONE }
                Thread.sleep(2500)
                val echo = rc.ime
                val matched = echo.value.contains(text)
                echoMatched = matched
                log(
                    if (matched) "صدى التلفزيون: الحقل يحتوي النص المرسل (قرينة فقط، لا تغني عن تأكيدك)"
                    else "لم يصل صدى يحتوي النص (قد يكون طبيعياً؛ المعتمد ما تراه على الشاشة). آخر قيمة أبلغ بها التلفزيون: «${echo.value}»"
                )
                ui {
                    b.echoStatus.text = (if (matched) "أبلغ التلفزيون أن الحقل يحتوي النص (قرينة).\n" else "لم يُبلغ التلفزيون بمحتوى الحقل (قد يكون طبيعياً).\n") +
                        "انظر الآن إلى شاشة التلفزيون وأجب أدناه. لم يُضغط أي زر إرسال."
                    b.verdictGroup.visibility = View.VISIBLE
                }
            } catch (e: Exception) {
                log("تعذّر إدراج النص: ${e.message}")
                ui { b.echoStatus.text = "تعذّر إدراج النص: ${e.message}" }
            }
        }
    }

    private fun setVerdict(text: String) {
        verdict = text
        log("النتيجة النهائية: $text")
        b.verdictStatus.text = text
    }

    // ------------------------------------------------------------------ التقرير

    private fun copyReport() {
        val version = try {
            @Suppress("DEPRECATION")
            packageManager.getPackageInfo(packageName, 0).versionName
        } catch (e: Exception) {
            "?"
        }
        val summary = buildString {
            appendLine("=== ملخص فحص HERO TV VOICE (v$version) ===")
            appendLine("المنفذ 6467: ${tcp6467.label()} | المنفذ 6466: ${tcp6466.label()}")
            appendLine("الاقتران: ${if (paired) "تم" else "لم يتم"} | اتصال التحكم: ${if (connected) "نجح ($deviceInfo)" else "لم ينجح"}")
            appendLine("الحقل المركّز: ${focusedPackage.ifEmpty { "لم يُبلغ" }}${if (focusedPackage == MOHAMED_PKG) " (Mohamed TV AI Assistant)" else ""}")
            appendLine("نص عربي أُرسل: ${textSent ?: "لا"} | صدى التلفزيون: ${echoMatched.label()}")
            appendLine("حكم المستخدم على الشاشة: $verdict")
            appendLine("=== السجل ===")
        }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("HERO TV VOICE report", summary + report))
        toast(getString(R.string.diag_report_copied))
    }

    private fun Boolean?.label() = when (this) {
        true -> "نعم"
        false -> "لا"
        null -> "لم يُفحص"
    }

    private companion object {
        const val PREFS = "hero_tv_voice_diag"
        const val KEY_HOST = "last_host"
        const val MOHAMED_PKG = "com.tvai.assistant.next"

        /** عناوين الشبكات المحلية فقط (RFC1918 + link-local). لا نتصل بأي عنوان عام. */
        fun isPrivateIpv4(h: String): Boolean {
            val p = h.split('.')
            if (p.size != 4) return false
            val n = p.map { it.toIntOrNull() ?: return false }
            if (n.any { it !in 0..255 }) return false
            return n[0] == 10 ||
                (n[0] == 172 && n[1] in 16..31) ||
                (n[0] == 192 && n[1] == 168) ||
                (n[0] == 169 && n[1] == 254)
        }
    }
}
