package com.herotoner.herotvvoice.command

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class CommandParserTest {

    private fun action(text: String): TvAction? = CommandParser.parse(text)?.action

    @Test
    fun requiredCommandsFromSpec() {
        assertEquals(TvAction.OPEN_SETTINGS, action("افتح الإعدادات"))
        assertEquals(TvAction.VOLUME_UP, action("ارفع الصوت"))
        assertEquals(TvAction.VOLUME_DOWN, action("اخفض الصوت"))
        assertEquals(TvAction.BACK, action("ارجع للخلف"))
        assertEquals(TvAction.UP, action("انتقل للأعلى"))
        assertEquals(TvAction.DOWN, action("انتقل للأسفل"))
        assertEquals(TvAction.SELECT, action("اختر العنصر المحدد"))
        assertEquals(TvAction.HOME, action("ارجع إلى الشاشة الرئيسية"))
    }

    @Test
    fun openApp() {
        val c = CommandParser.parse("افتح يوتيوب")
        assertNotNull(c)
        assertEquals(TvAction.OPEN_APP, c!!.action)
        assertEquals("يوتيوب", c.arg)

        val c2 = CommandParser.parse("افتح تطبيق اليوتيوب")
        assertEquals("يوتيوب", c2!!.arg)
    }

    @Test
    fun variants() {
        assertEquals(TvAction.VOLUME_UP, action("ارفع الصوت قليلا"))
        assertEquals(TvAction.VOLUME_DOWN, action("نزّل الصوت"))
        assertEquals(TvAction.MUTE, action("اكتم الصوت"))
        assertEquals(TvAction.HOME, action("الصفحة الرئيسية"))
        assertEquals(TvAction.BACK, action("رجوع"))
        assertEquals(TvAction.LEFT, action("يسار"))
        assertEquals(TvAction.RIGHT, action("إلى اليمين"))
        assertEquals(TvAction.SELECT, action("موافق"))
    }

    @Test
    fun rejectsUnknownOrAmbiguous() {
        assertNull(CommandParser.parse(""))
        assertNull(CommandParser.parse("   "))
        assertNull(CommandParser.parse("مرحبا كيف الحال"))
        assertNull(CommandParser.parse("أعلى الصوت"))      // فعل صوت غير مفهوم: لا نخمّن
        assertNull(CommandParser.parse("افتح"))            // بلا اسم تطبيق
    }

    @Test
    fun appArgumentNeverContainsPunctuation() {
        // علامات الترقيم تُحذف عند التطبيع، فلا يصل إلى الوسيط إلا حروف وأرقام ومسافات
        val c = CommandParser.parse("افتح ;rm -rf /")
        if (c != null) {
            assertEquals(true, Regex("^[\\p{L}\\p{N} ]+$").matches(c.arg!!))
        }
    }

    @Test
    fun rejectsTooLongAppName() {
        assertNull(CommandParser.parse("افتح " + "ا".repeat(60)))
    }

    @Test
    fun normalizerBasics() {
        assertEquals("الاعدادات", ArabicNormalizer.normalize("الإعدادات"))
        assertEquals("الصوت", ArabicNormalizer.normalize("اَلصَّوْتـ"))
        assertEquals("ارفع الصوت", ArabicNormalizer.normalize("  ارفع،  الصوت! "))
    }

    @Test
    fun wireNamesAreUnique() {
        assertEquals(TvAction.entries.size, TvAction.entries.map { it.wireName }.toSet().size)
    }
}
