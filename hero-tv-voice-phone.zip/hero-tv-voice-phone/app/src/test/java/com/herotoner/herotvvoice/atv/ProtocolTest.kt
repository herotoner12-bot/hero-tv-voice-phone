package com.herotoner.herotvvoice.atv

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.security.interfaces.RSAPublicKey

/**
 * اختبارات طبقة البروتوكول فقط (بلا شبكة).
 * المتجهات الذهبية (hex) وُلِّدت من مكتبة androidtvremote2 المرجعية (ملفات protobuf الرسمية)،
 * فتطابقها يعني أن ترميزنا اليدوي مطابق بايتاً ببايت لما تنتجه المكتبة المرجعية.
 * هذا لا يثبت سلوك تلفزيون حقيقي.
 */
class ProtocolTest {

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }
    private fun unhex(s: String) = ByteArray(s.length / 2) { s.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

    // ---------------------------------------------------------------- ترميز (Encoders)

    @Test fun poloPairingRequest() = assertEquals(
        "080210c801521a0a0961747672656d6f7465120d4845524f20545620564f494345",
        hex(Polo.pairingRequest("atvremote", "HERO TV VOICE"))
    )

    @Test fun poloOptionsAndConfiguration() {
        assertEquals("080210c801a201080a04080310061801", hex(Polo.options()))
        assertEquals("080210c801f201080a04080310061001", hex(Polo.configuration()))
    }

    @Test fun poloSecret() = assertEquals(
        "080210c801c202220a200102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f20",
        hex(Polo.secret(ByteArray(32) { (it + 1).toByte() }))
    )

    @Test fun remoteConfigureReplyAndActive() {
        assertEquals("0a1c08e704121718012201312a0961747672656d6f74653205312e302e30", hex(Remote.configureReply(615)))
        assertEquals("120308e704", hex(Remote.setActive(615)))
    }

    @Test fun remotePing() {
        assertEquals("4a020805", hex(Remote.pingResponse(5)))
        assertEquals("4a00", hex(Remote.pingResponse(0)))
        assertEquals("4a0408c0c407", hex(Remote.pingResponse(123456)))
    }

    @Test fun remoteKeys() {
        assertEquals("520408131003", hex(Remote.keyInject(Remote.KEYCODE_DPAD_UP)))
        assertEquals("520408171003", hex(Remote.keyInject(Remote.KEYCODE_DPAD_CENTER)))
        assertEquals("520408041003", hex(Remote.keyInject(Remote.KEYCODE_BACK)))
    }

    @Test fun imeArabicText() = assertEquals(
        "aa013f080310071a3908011235081910191a2fd8a7d8aed8aad8a8d8a7d8b120d8a7d984d8a5d8b1d8b3d8a7d98420d8a7d984d8b9d8b1d8a8d98a20d9a1d9a2d9a3",
        hex(Remote.imeInsertText(3, 7, "اختبار الإرسال العربي ١٢٣"))
    )

    @Test fun imeZeroCountersEmojiAndBigCounters() {
        assertEquals("aa010f1a0d08011209080310031a03616263", hex(Remote.imeInsertText(0, 0, "abc")))
        // الإيموجي خارج BMP: الطول يُحسب بنقاط الترميز لا بوحدات UTF-16
        assertEquals("aa0116080210091a100801120c080310031a06f09f98806162", hex(Remote.imeInsertText(2, 9, "😀ab")))
        assertEquals("aa011408ac0210f0a2041a0b08011207080110011a0178", hex(Remote.imeInsertText(300, 70000, "x")))
    }

    // ---------------------------------------------------------------- فك الترميز (Decoders)

    @Test fun decodeConfigure() {
        val m = Remote.parse(unhex("0a2408ee04121f0a08536d617274205456120c47656e6572616c636c6173733205392e392e39"))
        assertTrue(m is Remote.Incoming.Configure)
        m as Remote.Incoming.Configure
        assertEquals(622, m.supportedFeatures)
        assertEquals("Generalclass", m.vendor)
        assertEquals("Smart TV", m.model)
    }

    @Test fun decodeImeFieldWithArabicValue() {
        val m = Remote.parse(
            unhex(
                "a2014a0a34080b52174d6f68616d656420545620414920417373697374616e746217636f6d2e747661692e617373697374616e742e6e65787412120805120ad985d8b1d8add8a8d8a718052005"
            )
        )
        assertTrue(m is Remote.Incoming.ImeKeyInject)
        m as Remote.Incoming.ImeKeyInject
        assertEquals("com.tvai.assistant.next", m.appPackage)
        assertEquals("Mohamed TV AI Assistant", m.appLabel)
        assertEquals(11, m.imeCounter)
        assertEquals(5, m.fieldCounter)
        assertEquals("مرحبا", m.value)
        assertTrue(m.hasFieldStatus)
    }

    @Test fun decodeImeWithoutFocusedField() {
        val m = Remote.parse(unhex("a201090a0708016203782e79")) as Remote.Incoming.ImeKeyInject
        assertFalse(m.hasFieldStatus)
        assertEquals("x.y", m.appPackage)
    }

    @Test fun decodeMisc() {
        assertEquals(42, (Remote.parse(unhex("4204082a1001")) as Remote.Incoming.Ping).val1)
        val v = Remote.parse(unhex("9203063064380c4001")) as Remote.Incoming.Volume
        assertEquals(12, v.level); assertEquals(100, v.max); assertTrue(v.muted)
        assertTrue(Remote.parse(unhex("d205030a0178")) is Remote.Incoming.Unknown)
    }

    @Test fun decodePoloReplies() {
        val ack = Polo.parse(unhex("080210c8015a0b0a094c6976696e67205456"))
        assertEquals(200, ack.status); assertEquals(Polo.Kind.PAIRING_REQUEST_ACK, ack.kind); assertEquals("Living TV", ack.serverName)
        assertEquals(Polo.Kind.OPTIONS, Polo.parse(unhex("080210c801a20100")).kind)
        assertEquals(Polo.Kind.CONFIGURATION_ACK, Polo.parse(unhex("080210c801fa0100")).kind)
        assertEquals(Polo.Kind.SECRET_ACK, Polo.parse(unhex("080210c801ca02030a0101")).kind)
        assertEquals(402, Polo.parse(unhex("0802109203")).status)
    }

    // ---------------------------------------------------------------- الإطارات

    @Test fun framesRoundTrip() {
        val bos = ByteArrayOutputStream()
        Frames.write(bos, ByteArray(300) { it.toByte() })
        Frames.write(bos, ByteArray(0))
        Frames.write(bos, byteArrayOf(1, 2, 3))
        val ins = ByteArrayInputStream(bos.toByteArray())
        assertEquals(300, Frames.read(ins)!!.size)
        assertEquals(0, Frames.read(ins)!!.size)
        assertTrue(Frames.read(ins)!!.contentEquals(byteArrayOf(1, 2, 3)))
        assertEquals(null, Frames.read(ins))
    }

    // ---------------------------------------------------------------- الهوية والرمز السري

    @Test fun generatedIdentityIsValidAndSerializable() {
        val id = ClientIdentity.generate()
        val pub = id.certificate.publicKey as RSAPublicKey
        assertEquals(2048, pub.modulus.bitLength())
        id.certificate.verify(pub) // موقّعة ذاتياً
        val back = ClientIdentity.deserialize(id.serialize())
        assertEquals(hex(id.certificate.encoded), hex(back.certificate.encoded))
        assertEquals(64 + 31, fingerprintSha256(id.certificate.encoded).length) // 32 بايت "AA:BB:..."
    }

    @Test fun identityStoreLoadOrCreateIsStable() {
        val store = InMemoryIdentityStore()
        val a = store.loadOrCreate()
        val b = store.loadOrCreate()
        assertEquals(hex(a.certificate.encoded), hex(b.certificate.encoded))
        store.clear()
        assertTrue(store.load() == null)
    }

    @Test fun secretMatchesIndependentComputationAndPinPrefix() {
        val client = ClientIdentity.generate().certificate
        val server = ClientIdentity.generate().certificate
        val secret = PairingClient.computeSecret(client, server, "1a2b3c")
        val c = client.publicKey as RSAPublicKey
        val s = server.publicKey as RSAPublicKey
        val md = MessageDigest.getInstance("SHA-256")
        md.update(c.modulus.toByteArray().dropWhile { it == 0.toByte() }.toByteArray())
        md.update(c.publicExponent.toByteArray().dropWhile { it == 0.toByte() }.toByteArray())
        md.update(s.modulus.toByteArray().dropWhile { it == 0.toByte() }.toByteArray())
        md.update(s.publicExponent.toByteArray().dropWhile { it == 0.toByte() }.toByteArray())
        md.update(byteArrayOf(0x2b, 0x3c))
        assertEquals(hex(md.digest()), hex(secret))
        assertEquals(32, secret.size)
    }

    @Test fun pinNormalizationRejectsBadInput() {
        assertEquals("1A2B3C", PairingClient.normalizePin(" 1a 2b3c "))
        for (bad in listOf("", "12345", "1234567", "12345G", "١٢٣٤٥٦")) {
            try {
                PairingClient.normalizePin(bad)
                fail("كان يجب رفض الرمز: $bad")
            } catch (e: PairingException) {
                assertEquals(PairingException.Kind.BAD_PIN, e.kind)
            }
        }
    }

    // ---------------------------------------------------------------- سلامة: لا Enter ولا أسطر جديدة

    private val noopListener = object : RemoteClient.Listener {
        override fun onLog(line: String) {}
        override fun onImeUpdate(state: ImeState) {}
        override fun onClosed(reason: String?) {}
    }

    @Test fun enterKeyIsNeverAllowed() {
        val rc = RemoteClient(ClientIdentity.generate(), null, noopListener)
        for (code in listOf(66 /*ENTER*/, 160 /*NUMPAD_ENTER*/, 62 /*SPACE*/, 85 /*MEDIA_PLAY_PAUSE*/, 26 /*POWER*/)) {
            try {
                rc.sendKey(code)
                fail("زر غير مسموح مرّ: $code")
            } catch (e: IllegalArgumentException) {
                // المتوقع
            }
        }
    }

    @Test fun textWithNewlinesOrEmptyIsRejectedBeforeAnyNetwork() {
        val rc = RemoteClient(ClientIdentity.generate(), null, noopListener)
        for (t in listOf("", "سطر1\nسطر2", "a\rb")) {
            try {
                rc.sendText(t)
                fail("نص مرفوض مرّ: '$t'")
            } catch (e: IllegalArgumentException) {
                // المتوقع
            }
        }
    }
}
