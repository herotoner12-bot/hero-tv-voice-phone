import com.herotoner.herotvvoice.atv.*
import java.io.File
import java.util.Base64

var pass = 0; var fail = 0
fun check(ok: Boolean, label: String, detail: String = "") {
    if (ok) { pass++; println("PASS  $label") } else { fail++; println("FAIL  $label  $detail") }
}
fun waitFor(ms: Long, cond: () -> Boolean): Boolean { val end = System.currentTimeMillis() + ms; while (System.currentTimeMillis() < end) { if (cond()) return true; Thread.sleep(50) }; return cond() }

class L : RemoteClient.Listener {
    override fun onLog(line: String) { println("   [remote] $line") }
    override fun onImeUpdate(state: ImeState) { println("   [ime] pkg=${state.appPackage} ic=${state.imeCounter} fc=${state.fieldCounter} value='${state.value}'") }
    override fun onClosed(reason: String?) { println("   [closed] $reason") }
}

fun main(args: Array<String>) {
    val dir = File(args[0]); val mode = args[1]; val host = "127.0.0.1"
    val pairPort = args[2].toInt(); val remotePort = args[3].toInt()
    val identity = ClientIdentity.generate()
    // الشهادة التي ولّدها الكود (X509Builder) يجب أن يقبلها OpenSSL/Python
    File(dir, "client.pem").writeText("-----BEGIN CERTIFICATE-----\n" +
        Base64.getMimeEncoder(64, "\n".toByteArray()).encodeToString(identity.certificate.encoded) + "\n-----END CERTIFICATE-----\n")
    File(dir, "identity.bin").writeBytes(identity.serialize())
    check(true, "identity generated (RSA-2048 + X509Builder cert)")
    // إعادة التحميل من التسلسل
    val reloaded = ClientIdentity.deserialize(identity.serialize())
    check(reloaded.certificate.encoded.contentEquals(identity.certificate.encoded), "identity serialize/deserialize round trip")
    println("   cert subject=${identity.certificate.subjectX500Principal} sigAlg=${identity.certificate.sigAlgName} ca=${identity.certificate.basicConstraints}")

    File(dir, "gen_done").writeText("1")
    // انتظر الخادم الوهمي
    check(waitFor(20000) { File(dir, "ready").exists() }, "mock TV ready")

    val t6467 = PortProbe.tcp(host, pairPort); val t6466 = PortProbe.tcp(host, remotePort)
    check(t6467.open && t6466.open, "TCP probe both ports open", "${t6467.error} ${t6466.error}")
    val tls = PortProbe.tls(host, pairPort, identity)
    check(tls.ok && tls.fingerprint == File(dir, "server_fingerprint.txt").readText().trim(), "TLS probe on pairing port sees server cert with expected fingerprint", "${tls.error} ${tls.fingerprint}")
    check(!PortProbe.tcp(host, 1).open, "closed port reported closed")

    // قبل الاقتران: منفذ التحكم يجب أن يرفض
    val unpaired = RemoteClient(identity, null, L())
    val e0 = runCatching { unpaired.connect(host, remotePort, 4000) }.exceptionOrNull()
    check(e0 != null, "remote connect BEFORE pairing fails", "unexpectedly connected")
    println("   reason: ${e0?.message}")
    unpaired.close()

    // الاقتران
    val pc = PairingClient(identity)
    val fp = pc.start(host, pairPort)
    check(fp == File(dir, "server_fingerprint.txt").readText().trim(), "pairing start returns server fingerprint")
    check(waitFor(5000) { File(dir, "pin.txt").exists() }, "TV displayed PIN")
    val pin = File(dir, "pin.txt").readText().trim()
    val wrong = pin.substring(0, 2) + (if (pin.substring(2) == "0000") "0001" else "0000")
    val badPin = runCatching { pc.finish("12") }.exceptionOrNull()
    check(badPin is PairingException && badPin.kind == PairingException.Kind.BAD_PIN, "short PIN rejected locally")
    val badPin2 = runCatching { pc.finish("ZZZZZZ") }.exceptionOrNull()
    check(badPin2 is PairingException && badPin2.kind == PairingException.Kind.BAD_PIN, "non-hex PIN rejected locally")
    val badPin3 = runCatching { pc.finish(wrong) }.exceptionOrNull()
    check(badPin3 is PairingException && badPin3.kind == PairingException.Kind.BAD_PIN, "wrong PIN rejected (locally by hash check)", "$badPin3")
    if (mode == "reject") {
        val r = runCatching { pc.finish(pin) }.exceptionOrNull()
        check(r is PairingException && r.kind == PairingException.Kind.BAD_PIN, "server-side 402 BAD_SECRET mapped to BAD_PIN", "$r")
        println("== e2e($mode): $pass passed, $fail failed =="); System.exit(if (fail > 0) 1 else 0)
    }
    val fp2 = pc.finish(pin)
    check(fp2 == fp, "pairing finished with correct PIN")
    pc.close()

    // التحكم بعد الاقتران، مع تثبيت البصمة
    val bad = RemoteClient(identity, "00:11", L())
    val e1 = runCatching { bad.connect(host, remotePort, 4000) }.exceptionOrNull()
    check(e1 != null, "remote connect with WRONG pinned fingerprint is refused")
    println("   reason: ${e1?.message}"); bad.close()

    val rc = RemoteClient(identity, fp, L())
    val info = rc.connect(host, remotePort, 8000)
    check(info.vendor == "MockVendor" && info.model == "MockTV", "remote connected; device info parsed", "${info.vendor} ${info.model}")
    check(info.supportsIme && info.supportsKeys, "IME + KEY negotiated", "active=${info.activeFeatures}")
    check(info.activeFeatures == (Remote.DESIRED_FEATURES and 622), "active features = desired & supported", "${info.activeFeatures}")
    check(waitFor(5000) { rc.ime.hasFieldStatus }, "TV reported a focused text field")
    check(rc.ime.appPackage == "com.tvai.assistant.next" && rc.ime.imeCounter == 11 && rc.ime.fieldCounter == 5, "focused field belongs to Mohamed TV package; counters read", "${rc.ime}")

    // مفاتيح يدوية
    rc.sendKey(Remote.KEYCODE_DPAD_DOWN); rc.sendKey(Remote.KEYCODE_DPAD_CENTER)
    check(runCatching { rc.sendKey(66) }.exceptionOrNull() is IllegalArgumentException, "ENTER (66) is not sendable")
    check(runCatching { rc.sendText("a\nb") }.exceptionOrNull() is IllegalArgumentException, "text with newline refused")
    check(runCatching { rc.sendText("") }.exceptionOrNull() is IllegalArgumentException, "empty text refused")

    // إدراج النص العربي
    val arabic = "اختبار الإرسال العربي ١٢٣"
    val used = rc.sendText(arabic)
    println("   sendText used: $used")
    check(waitFor(5000) { rc.ime.value == arabic }, "TV echoed field value == Arabic text sent", "got='${rc.ime.value}'")
    check(rc.ime.fieldCounter == 6, "field counter advanced by TV echo (6)", "${rc.ime.fieldCounter}")
    rc.sendText(" مرحبا")
    check(waitFor(5000) { rc.ime.value == "$arabic مرحبا" }, "second insert uses updated counters and is accepted", "got='${rc.ime.value}'")
    Thread.sleep(2500) // اسمح بوصول طلبات ping من الخادم
    check(rc.isOpen, "session still open after pings")
    rc.close()
    println("== e2e($mode): $pass passed, $fail failed =="); System.exit(if (fail > 0) 1 else 0)
}
