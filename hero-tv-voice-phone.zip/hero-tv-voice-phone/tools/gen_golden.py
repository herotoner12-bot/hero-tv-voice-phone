# Generates golden vectors using the OFFICIAL protoc-generated classes of the reference library.
from androidtvremote2.polo_pb2 import OuterMessage, Options
from androidtvremote2.remotemessage_pb2 import RemoteMessage, RemoteImeObject, RemoteEditInfo, RemoteImeBatchEdit
lines = []
def enc(name, msg): lines.append(f"ENC|{name}|{msg.SerializeToString().hex()}")
def outer():
    m = OuterMessage(); m.protocol_version = 2; m.status = OuterMessage.Status.STATUS_OK; return m

m = outer(); m.pairing_request.client_name = "HERO TV VOICE"; m.pairing_request.service_name = "atvremote"; enc("polo_pairing_request", m)
m = outer(); m.options.preferred_role = Options.RoleType.ROLE_TYPE_INPUT
e = m.options.input_encodings.add(); e.type = Options.Encoding.ENCODING_TYPE_HEXADECIMAL; e.symbol_length = 6; enc("polo_options", m)
m = outer(); m.configuration.client_role = Options.RoleType.ROLE_TYPE_INPUT
m.configuration.encoding.type = Options.Encoding.ENCODING_TYPE_HEXADECIMAL; m.configuration.encoding.symbol_length = 6; enc("polo_configuration", m)
m = outer(); m.secret.secret = bytes(range(1, 33)); enc("polo_secret", m)

def cfg(feat):
    m = RemoteMessage(); m.remote_configure.code1 = feat
    m.remote_configure.device_info.unknown1 = 1; m.remote_configure.device_info.unknown2 = "1"
    m.remote_configure.device_info.package_name = "atvremote"; m.remote_configure.device_info.app_version = "1.0.0"; return m
enc("remote_configure_reply_615", cfg(615)); enc("remote_configure_reply_7", cfg(7))
m = RemoteMessage(); m.remote_set_active.active = 615; enc("remote_set_active_615", m)
for v in (5, 0, 123456):
    m = RemoteMessage(); m.remote_ping_response.val1 = v; enc(f"remote_ping_response_{v}", m)
for k in (19, 20, 21, 22, 23, 3, 4):
    m = RemoteMessage(); m.remote_key_inject.key_code = k; m.remote_key_inject.direction = 3; enc(f"remote_key_{k}", m)
def ime(ic, fc, text):
    m = RemoteMessage()
    n = len(text)
    m.remote_ime_batch_edit.CopyFrom(RemoteImeBatchEdit(ime_counter=ic, field_counter=fc, edit_info=[RemoteEditInfo(insert=1, text_field_status=RemoteImeObject(start=n, end=n, value=text))]))
    return m
enc("ime_arabic_3_7", ime(3, 7, "اختبار الإرسال العربي ١٢٣"))
enc("ime_zero_counters_abc", ime(0, 0, "abc"))
enc("ime_emoji", ime(2, 9, "😀ab"))
enc("ime_big_counters", ime(300, 70000, "x"))

# decode cases: official messages -> expected summary computed by Kotlin side from fields below
def dec(name, msg, summary): lines.append(f"DEC|{name}|{msg.SerializeToString().hex()}|{summary}")
m = RemoteMessage(); m.remote_configure.code1 = 622; m.remote_configure.device_info.model = "Smart TV"; m.remote_configure.device_info.vendor = "Generalclass"; m.remote_configure.device_info.app_version = "9.9.9"
dec("configure", m, "Configure:622:Generalclass:Smart TV:9.9.9")
m = RemoteMessage(); m.remote_set_active.active = 615; dec("set_active", m, "SetActive:615")
m = RemoteMessage(); m.remote_ping_request.val1 = 42; m.remote_ping_request.val2 = 1; dec("ping", m, "Ping:42")
m = RemoteMessage(); m.remote_start.started = True; dec("start", m, "Start:true")
m = RemoteMessage(); m.remote_ime_key_inject.app_info.counter = 11; m.remote_ime_key_inject.app_info.app_package = "com.tvai.assistant.next"; m.remote_ime_key_inject.app_info.label = "Mohamed TV AI Assistant"
m.remote_ime_key_inject.text_field_status.counter_field = 5; m.remote_ime_key_inject.text_field_status.value = "مرحبا"; m.remote_ime_key_inject.text_field_status.start = 5; m.remote_ime_key_inject.text_field_status.end = 5
dec("ime_key_inject", m, "ImeKeyInject:com.tvai.assistant.next:Mohamed TV AI Assistant:11:5:مرحبا:5:5:true")
m = RemoteMessage(); m.remote_ime_key_inject.app_info.counter = 1; m.remote_ime_key_inject.app_info.app_package = "x.y"
dec("ime_key_inject_no_field", m, "ImeKeyInject:x.y::1:0::0:0:false")
m = RemoteMessage(); m.remote_ime_show_request.remote_text_field_status.counter_field = 8; m.remote_ime_show_request.remote_text_field_status.value = "abc"
dec("ime_show", m, "ImeShowRequest:8:abc:true")
m = ime(4, 6, "q"); dec("ime_batch", m, "ImeBatchEdit:4:6")
m = RemoteMessage(); m.remote_error.value = True; dec("error", m, "Error:true")
m = RemoteMessage(); m.remote_set_volume_level.volume_level = 12; m.remote_set_volume_level.volume_max = 100; m.remote_set_volume_level.volume_muted = True
dec("volume", m, "Volume:12:100:true")
m = RemoteMessage(); m.remote_app_link_launch_request.app_link = "x"; dec("unknown", m, "Unknown:[90]")

def polo(name, build, summary):
    m = OuterMessage(); m.protocol_version = 2; build(m); lines.append(f"POLO|{name}|{m.SerializeToString().hex()}|{summary}")
polo("ack", lambda m: (setattr(m, 'status', 200), setattr(m.pairing_request_ack, 'server_name', 'Living TV')), "200:PAIRING_REQUEST_ACK:Living TV")
polo("options", lambda m: (setattr(m, 'status', 200), m.options.SetInParent()), "200:OPTIONS:")
polo("cfg_ack", lambda m: (setattr(m, 'status', 200), m.configuration_ack.SetInParent()), "200:CONFIGURATION_ACK:")
polo("secret_ack", lambda m: (setattr(m, 'status', 200), m.secret_ack.secret.__class__ and setattr(m.secret_ack, 'secret', b'\x01')), "200:SECRET_ACK:")
polo("bad_secret", lambda m: setattr(m, 'status', 402), "402:OTHER:")
open("golden.txt", "w", encoding="utf-8").write("\n".join(lines) + "\n")
print(len(lines), "vectors written")
