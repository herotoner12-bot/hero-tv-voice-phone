#!/usr/bin/env python3
"""
تلفزيون Android TV وهمي لاختبار طبقة البروتوكول محلياً (ليس بديلاً عن تلفزيون حقيقي!).

يحاكي بحسب مواصفة المرجع المفتوح androidtvremote2:
  - منفذ الاقتران (TLS): pairing_request -> options -> configuration -> يعرض PIN -> secret.
  - منفذ التحكم (TLS): يقبل فقط الهواتف المقترنة، يرسل configure/set_active/start/ping،
    ثم remote_ime_key_inject (حقل كتابة مركّز بعدّادات)، ويتجاهل أي إدراج نص بعدّادات قديمة.

المتطلبات: pip install androidtvremote2 protobuf cryptography
الاستخدام: mock_tv.py <dir> <pairing_port> <remote_port> [normal|reject]
المخرجات داخل <dir>: pin.txt, events.jsonl
المتغير: يقرأ <dir>/client.pem (شهادة الهاتف) ليسمح بمصافحة TLS في منفذ الاقتران.
"""
import hashlib, json, os, random, socket, ssl, struct, sys, threading, time
from datetime import datetime, timedelta, timezone

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID
from androidtvremote2.polo_pb2 import OuterMessage, Options
from androidtvremote2.remotemessage_pb2 import RemoteMessage

D, PAIR_PORT, REMOTE_PORT = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
MODE = sys.argv[4] if len(sys.argv) > 4 else "normal"
TV_FEATURES = 622          # KEY | IME | VOICE | POWER | VOLUME | APP_LINK (بدون PING كما في أجهزة حقيقية)
APP_PKG = "com.tvai.assistant.next"
IME_COUNTER = 11

lock = threading.Lock()
trusted = []               # شهادات الهواتف المقترنة (PEM)
state = {"field_counter": 5, "value": ""}


def log(kind, **kw):
    with lock, open(os.path.join(D, "events.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps({"t": round(time.time(), 3), "kind": kind, **kw}, ensure_ascii=False) + "\n")


# ---------- شهادة التلفزيون ----------
key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "mock-androidtv")])
now = datetime.now(timezone.utc)
cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
        .serial_number(7).not_valid_before(now - timedelta(hours=1)).not_valid_after(now + timedelta(days=3650))
        .sign(key, hashes.SHA256()))
SRV_CERT = os.path.join(D, "server.pem"); SRV_KEY = os.path.join(D, "server.key")
open(SRV_CERT, "wb").write(cert.public_bytes(serialization.Encoding.PEM))
open(SRV_KEY, "wb").write(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL, serialization.NoEncryption()))
open(os.path.join(D, "server_fingerprint.txt"), "w").write(
    ":".join("%02X" % b for b in hashlib.sha256(cert.public_bytes(serialization.Encoding.DER)).digest()))


def tbytes(n): return n.to_bytes((n.bit_length() + 7) // 8, "big")


def mk_ctx(trust_pems, required):
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(SRV_CERT, SRV_KEY)
    ctx.verify_mode = ssl.CERT_REQUIRED if required else ssl.CERT_OPTIONAL
    for pem in trust_pems:
        ctx.load_verify_locations(cadata=pem.decode())
    return ctx


# ---------- إطارات varint ----------
def read_frame(conn):
    n, shift = 0, 0
    while True:
        b = conn.recv(1)
        if not b: return None
        n |= (b[0] & 0x7F) << shift
        if not b[0] & 0x80: break
        shift += 7
    buf = b""
    while len(buf) < n:
        c = conn.recv(n - len(buf))
        if not c: return None
        buf += c
    return buf


def write_frame(conn, data):
    n, hdr = len(data), b""
    while True:
        if n < 0x80: hdr += bytes([n]); break
        hdr += bytes([(n & 0x7F) | 0x80]); n >>= 7
    conn.sendall(hdr + data)


# ---------- الاقتران ----------
def polo(**kw):
    m = OuterMessage(); m.protocol_version = 2; m.status = kw.pop("status", 200); return m


def handle_pairing(conn):
    peer = conn.getpeercert(binary_form=True)
    if not peer:
        log("pair_no_client_cert"); return
    c = x509.load_der_x509_certificate(peer); s = cert
    cn, ce = c.public_key().public_numbers().n, c.public_key().public_numbers().e
    sn, se = s.public_key().public_numbers().n, s.public_key().public_numbers().e
    expected = None
    while True:
        raw = read_frame(conn)
        if raw is None: log("pair_closed"); return
        m = OuterMessage(); m.ParseFromString(raw)
        if m.HasField("pairing_request"):
            log("pair_request", client=m.pairing_request.client_name, service=m.pairing_request.service_name)
            r = polo(); r.pairing_request_ack.server_name = "MockTV"; write_frame(conn, r.SerializeToString())
        elif m.HasField("options"):
            r = polo(); r.options.preferred_role = Options.RoleType.ROLE_TYPE_OUTPUT
            e = r.options.output_encodings.add(); e.type = Options.Encoding.ENCODING_TYPE_HEXADECIMAL; e.symbol_length = 6
            write_frame(conn, r.SerializeToString())
        elif m.HasField("configuration"):
            r = polo(); r.configuration_ack.SetInParent(); write_frame(conn, r.SerializeToString())
            tail = bytes(random.randrange(256) for _ in range(2))
            h = hashlib.sha256()
            for part in (tbytes(cn), tbytes(ce), tbytes(sn), tbytes(se), tail): h.update(part)
            expected = h.digest()
            pin = "%02X%s" % (expected[0], tail.hex().upper())
            open(os.path.join(D, "pin.txt"), "w").write(pin)
            log("pin_shown")           # لا نسجّل الرمز نفسه في السجل
        elif m.HasField("secret"):
            ok = (MODE != "reject") and expected is not None and m.secret.secret == expected
            if ok:
                with lock: trusted.append(c.public_bytes(serialization.Encoding.PEM))
                r = polo(); r.secret_ack.secret = expected; write_frame(conn, r.SerializeToString())
                log("pair_ok")
            else:
                r = polo(status=402); write_frame(conn, r.SerializeToString())
                log("pair_bad_secret")
            return


# ---------- التحكم ----------
def rm(): return RemoteMessage()


def send_ime(conn, extra_counter=0):
    m = rm()
    m.remote_ime_key_inject.app_info.counter = IME_COUNTER
    m.remote_ime_key_inject.app_info.app_package = APP_PKG
    m.remote_ime_key_inject.app_info.label = "Mohamed TV AI Assistant"
    m.remote_ime_key_inject.text_field_status.counter_field = state["field_counter"]
    m.remote_ime_key_inject.text_field_status.value = state["value"]
    n = len(state["value"])
    m.remote_ime_key_inject.text_field_status.start = n
    m.remote_ime_key_inject.text_field_status.end = n
    write_frame(conn, m.SerializeToString())


def handle_remote(conn):
    state.update(field_counter=5, value="")
    m = rm(); m.remote_configure.code1 = TV_FEATURES
    m.remote_configure.device_info.vendor = "MockVendor"; m.remote_configure.device_info.model = "MockTV"
    m.remote_configure.device_info.app_version = "1.2.3"
    write_frame(conn, m.SerializeToString())
    started = False; ping_at = time.time() + 1.0; ime_sent = False
    conn.settimeout(0.2)
    while True:
        try:
            raw = read_frame(conn)
        except socket.timeout:
            raw = b"__timeout__"
        except (ssl.SSLError, OSError):
            return
        if raw is None: log("remote_closed"); return
        if raw != b"__timeout__":
            msg = rm(); msg.ParseFromString(raw)
            if msg.HasField("remote_configure"):
                log("configure_reply", code1=msg.remote_configure.code1, package=msg.remote_configure.device_info.package_name)
                a = rm(); a.remote_set_active.active = msg.remote_configure.code1; write_frame(conn, a.SerializeToString())
            elif msg.HasField("remote_set_active"):
                log("set_active_reply", active=msg.remote_set_active.active)
                s = rm(); s.remote_start.started = True; write_frame(conn, s.SerializeToString()); started = True
            elif msg.HasField("remote_ping_response"):
                log("ping_response", val1=msg.remote_ping_response.val1)
            elif msg.HasField("remote_key_inject"):
                k = msg.remote_key_inject
                log("key", key_code=k.key_code, direction=k.direction)
                if k.key_code in (66, 160):
                    log("ENTER_RECEIVED")
            elif msg.HasField("remote_ime_batch_edit"):
                b = msg.remote_ime_batch_edit
                edit = b.edit_info[0] if b.edit_info else None
                good = b.ime_counter == IME_COUNTER and b.field_counter == state["field_counter"]
                log("ime_batch_edit", ime_counter=b.ime_counter, field_counter=b.field_counter, accepted=good,
                    insert=edit.insert if edit else None,
                    text=edit.text_field_status.value if edit else None,
                    start=edit.text_field_status.start if edit else None, end=edit.text_field_status.end if edit else None)
                if good and edit:
                    state["value"] += edit.text_field_status.value
                    state["field_counter"] += 1
                    send_ime(conn)
            else:
                log("other_message", fields=[f.name for f, _ in msg.ListFields()])
        if started and not ime_sent and time.time() > ping_at:
            ime_sent = True
            send_ime(conn)
            log("ime_focus_sent")
        if started and time.time() > ping_at:
            p = rm(); p.remote_ping_request.val1 = int(time.time()) % 1000 + 1; write_frame(conn, p.SerializeToString())
            ping_at = time.time() + 1.0


def serve(port, handler, required, name):
    srv = socket.socket(); srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind(("127.0.0.1", port)); srv.listen(8)
    while True:
        raw, _ = srv.accept()
        def run(raw=raw):
            try:
                with lock: pems = list(trusted) + ([open(os.path.join(D, "client.pem"), "rb").read()] if not required else [])
                ctx = mk_ctx(pems, required)
                conn = ctx.wrap_socket(raw, server_side=True)
            except Exception as e:
                log("tls_rejected", port=name, reason=str(e)[:80]); raw.close(); return
            try:
                log("tls_ok", port=name); handler(conn)
            except Exception as e:
                log("handler_error", port=name, reason=repr(e)[:120])
            finally:
                try: conn.close()
                except Exception: pass
        threading.Thread(target=run, daemon=True).start()


threading.Thread(target=serve, args=(PAIR_PORT, handle_pairing, False, "pairing"), daemon=True).start()
threading.Thread(target=serve, args=(REMOTE_PORT, handle_remote, True, "remote"), daemon=True).start()
open(os.path.join(D, "ready"), "w").write("1")
while True: time.sleep(1)
